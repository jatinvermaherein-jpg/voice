# Hangar
- Central 3D hangar scene
- 5 active mech slots
- Top bar currencies/profile
- Battle button bottom-right
- Shop access
- Squad preset selector
