# Login Screen
- Full-screen splash artwork
- Connection status indicator
- Version/build info
- Automatic account login
- Branding replaced with project branding
