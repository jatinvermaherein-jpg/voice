# Squad Presets
- Multiple saved hangars
- Power rating display
- Copy preset
- Delete preset
- Active preset selection
