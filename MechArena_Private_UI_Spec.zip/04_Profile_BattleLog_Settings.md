# Profile Area
- Profile
- Battle Log
- Connection
- Settings
- Controls

Settings:
- Resolution
- Graphics Quality
- FPS Limit
- Fullscreen
- VSync

Controls:
- Mouse sensitivity
- Gamepad sensitivity
- Custom control layout
