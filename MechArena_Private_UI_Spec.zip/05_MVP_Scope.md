# MVP Scope
Included:
- All Mechs
- All Weapons
- Maps
- Login
- Hangar
- Inventory
- Pilots
- Mods
- Shop
- Matchmaking
- Match Results

Excluded:
- Events
- Battle Pass
- Live Ops
- Seasonal Systems
