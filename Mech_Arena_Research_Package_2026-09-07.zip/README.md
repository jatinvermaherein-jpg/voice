# Mech Arena research package

Research cut-off: **7 September 2026**. Observed release family: **3.470**.

## Main report
- `Mech_Arena_Systems_Dossier_2026-09-07.pdf` — print-ready report, linked contents, bookmarks, diagrams and citations.
- `Mech_Arena_Systems_Dossier_2026-09-07.docx` — editable modern Word document with headings, tables, source hyperlinks and embedded diagrams.
- `Mech_Arena_Systems_Dossier_2026-09-07.html` — self-contained offline report with chapter navigation; no network resources are needed to render it. External source links still require internet.
- `Mech_Arena_Systems_Dossier_2026-09-07.md` — portable source text; keep the `assets` folder alongside it for diagrams.

## Research data
- `evidence-ledger.csv` — 223 indexed assertions with classification, time scope and source URLs.
- `source-register.json` — 114 source records, authority, dates and caveats.
- `ecosystem-map.json` — 100 system nodes, 111 functional relationships, mode specifications, known technical facts and explicit unknowns.
- `assets/` — seven original SVG diagrams and PNG companions. Rich report formats embed their graphics.

## How to use it
1. Read the evidence key and Section 17.
2. Keep classification and temporal scope with any extracted claim.
3. Verify live Tournament/Showdown settings and the current organizer addenda before running a competition.
4. Treat `null` as unknown, not zero or absence.
5. Do not treat the conceptual graph as an extracted game API, database schema or proprietary algorithm.

The study indexed 127 English support articles and compared the relevant rules with official announcements, storefronts, technical writing and community/organizer sources. It did not create a game account, perform client gameplay experiments or decompile software. No individual-item catalog is included.

Independent analysis; not an official Plarium publication.
