# MECH ARENA

## Systems, Architecture & Ecosystem Research Dossier

**Public-source reconstruction • Research cut-off: 7 September 2026 • Current release family observed: 3.470**

Prepared for game designers, developers, competitive players, tournament organizers, researchers, analysts, wiki editors, community managers, and AI knowledge-system builders.

> **Scope.** This document explains how Mech Arena works as a connected product: combat, modes, player progression, matchmaking, competition, social structures, live operations, economy, technology, and external organized play. It deliberately does **not** enumerate individual mechs, weapons, pilots, implants, skins, or item-by-item balance statistics.

### Executive findings

1. **Mech Arena is a session-based, cross-platform tactical third-person mech shooter, not an open-world MMO or a simulation of persistent territorial warfare.** Short arena battles sit inside a much longer collection, upgrade, and social progression system. [O] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · PRODUCT [5](https://plarium.com/en/game/mech-arena/) · PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US)
2. **The account has several independent progression coordinates.** Account XP, League/Season RP, Tournament TRP, Gear Hub Tier Stars, equipment ranks/levels, Hangar Showdown leagues, and event points are not interchangeable. Treating all of them as one “rank” produces incorrect analyses. [O; synthesis] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown)
3. **A player's hangar is both a strategic portfolio and a mode-dependent supply of combat lives.** Five-mech depth matters differently in finite-life team battles, sequential Showdown rounds, and FFA's repeatable five-mech cycle. [O/C] MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes)
4. **There is no single uniform matchmaking specification.** Public documentation describes equipment-sensitive matching, selected-preset potential and achievements, equipment-based Showdown leagues, and TRP-driven Tournament progression. Exact weights, queue expansion, team balancing, and hidden skill calculations remain undisclosed. [O for documented inputs; S for any complete formula] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)
5. **The Tournament format changed materially in April 2026.** The current system has eight daily battle attempts, fifteen rank steps and a Legend Top 500. Old ticket/heat/20-player-bracket instructions must not be applied to it. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)
6. **FFA has three different success measures.** Top-three player placement determines match winners; the May Tournament policy grants A-Coins to the top five; the MVP presentation recognizes individual mech performances. These are different evaluation layers. [O] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)
7. **Showdown is not merely the old 2v2 Deathmatch renamed.** It changes selection, round structure, temporary equipment normalization, league restrictions, and daily reward progression. The ordinary public 2v2 queue was removed. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/)
8. **Solo PvE is not offline play.** Onslaught has its own first-clear rewards and equipment gates and explicitly excludes ordinary XP, RP, point, medal, objective, and battle-history progression. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · OFFLINE [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline)
9. **Payment is mechanically relevant, but its effect is mode-dependent.** Purchases can grant combat content and upgrade resources; Showdown normalizes ranks/levels but not the entire ownership and league-access landscape. Neither “cosmetics only” nor “spending guarantees victory” is an accurate system description. [O; latter conclusion is S-analysis] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass)
10. **The engineering evidence is stronger than generic speculation.** A Plarium developer describes Unity, NavMesh and an internally developed Astar navigation system, synchronized moving world objects, JSON level presets, internal editors, and Jenkins builds. This does **not** reveal the hosting vendor, full backend stack, tick rate, or comprehensive server authority model. [O / S-unknown] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)
11. **Clans are social and aggregate-leaderboard organizations.** The documented feature has 30-member rosters and power/damage leaderboards, not a verified clan technology tree, shared resource bank, or native clan-war ladder. [O for documented features; S-unknown for absent verification] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)
12. **The external competitive scene must be researched separately from the in-game Tournament button.** The live MAQC site shows Season 7, weekly best-of-three series, a six-week season, and a five-million-A-Coin pool. Cached Season 6 summaries and the earlier anniversary press-release pool are not the current organizer rulebook. [C; official promotion separately O] MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · MAQCOFF [3](https://x.com/MechArenaMobile/status/2058872024777252880)

### How to read the evidence

| Label | Meaning in this dossier | What it does not mean |
|---|---|---|
| **[O] Officially confirmed** | Explicitly stated in Plarium support, an identified staff response, an engineering article, an official release announcement, or an official storefront. | Independent testing of every implementation detail; proof that an old announcement is still current. |
| **[C] Community confirmed** | Documented by a community organizer, independent gameplay guide, or community-maintained reference. Organizer rules are primary evidence for that organizer's competition. | Plarium endorsement of every assertion, access to internal telemetry, or validation of hidden algorithms. |
| **[W] Widely believed** | A recurring community explanation or perception with insufficient evidence to treat the causal claim as established. | A fact promoted by repetition, voting, or an authoritative-sounding video. |
| **[S] Speculative** | An explicitly marked analytical inference, conceptual model, recommendation, proposed test, or unresolved proposition. | A statement that the game is known to implement the model. |

**Temporal qualifiers matter:** *current documented*, *historical*, *announced*, *experimental*, *discontinued*, and *unresolved* accompany evidence labels where needed. “Officially confirmed” means the publisher made the statement; advertised goals and projected benefits remain **claims about intent or expectations**, not independently measured results.

**Citation format.** Short source keys such as TRN, ENGINE, and CLAN identify entries in Section 17's source register. Each is followed by a clickable numeric source link. Source keys, rather than potentially repeated search-link numbers, are the stable identifiers across this document and its machine-readable companions.

**Method.** Research indexed the English Plarium help-center corpus of 127 articles, read the systems-relevant guides, compared them with dated forum announcements, checked storefront version histories, and consulted selected community and organizer sources. No account was created or played for this investigation. No client binary was decompiled, private API probed, or internal telemetry obtained. Public documentation can support a rigorous product reconstruction, but not a complete implementation-level reverse engineering of proprietary software.

**Source precedence.** Prefer a recent feature-specific rule or deployed-change notice over broad marketing copy; prefer the live organizer rulebook and current weekly addenda over cached event summaries; separate staff replies from user comments on the same forum page. Support API `updated_at` timestamps are not feature-launch dates. Screenshots and page paragraphs can themselves come from different versions. Section 17 records consequential conflicts rather than silently picking convenient answers.

### Contents

1. Game identification and evolution
2. High-level system architecture and loops
3. Complete player journey
4. Mode-by-mode operational specifications
5. Anatomy of a match
6. Competitive progression and ranking systems
7. Matchmaking architecture and bot population
8. Clans and group organization
9. Events, seasons and live operations
10. Economy architecture
11. Social and community systems
12. Design philosophy and behavioral analysis
13. Technical framework and operational boundaries
14. Tournament ecosystem and organizer operations
15. Meta formation and balance dynamics
16. Structured ecosystem map and knowledge model
17. Fact checking, conflict ledger, unknowns and sources

---

# 1. Game identification and evolution

## 1.1 Product identity

**Mech Arena**, historically marketed as **Mech Arena: Robot Showdown** and also titled **Mech Arena – Shooting Game** in storefronts, is developed and published by **Plarium Global Ltd.** Its fundamental activity is real-time arena combat using configurable mechs, distinct abilities, and player-selected weapon loadouts. Third-person aiming, movement, positioning, ability timing, and team or individual objectives are the moment-to-moment interaction model. [O] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · PRODUCT [5](https://plarium.com/en/game/mech-arena/) · PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US) · WEB [7](https://mecharena.game/)

The clearest genre description is **free-to-play, session-based tactical multiplayer third-person shooter with persistent equipment progression**. It combines action execution with collection and loadout optimization. “MOBA-like,” “hero shooter,” and “RPG progression” can be useful comparisons, but the reviewed official rules do not establish lane economies, minion-wave base destruction, or a persistent adventure world as its core architecture. [O for described mechanics; S for genre synthesis] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch)

The objective is mode-dependent: accumulate territorial Influence, win kill-scoring rounds, place highly in FFA, win a sequence of restricted Showdown duels, or clear PvE enemies. Outside combat, players acquire and improve a hangar, unlock systems, advance ranking tracks, and collect rewards. There is no single campaign completion condition that describes the whole product. [O; synthesis] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path)

## 1.2 Platforms, distribution, and regions

| Channel | Confirmed position | Important boundary |
|---|---|---|
| Android | Official Google Play application, package `com.plarium.mechlegion`. [O] PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US) | Device/store compatibility, country, account, and age requirements can differ. |
| iOS / iPadOS | Official Apple application, ID `1377591228`. [O] APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) | Store “last compatible version” metadata is not a promise of current-client support. |
| Windows / macOS | Native desktop distribution through Plarium Play; desktop launch announced 3 August 2022. [O] PC [2](https://forum.plarium.com/en/mech-arena/854_news/31666_mech-arena-is-live-on-plarium-play/) · PRODUCT [5](https://plarium.com/en/game/mech-arena/) | An Android emulator is not required for the official desktop release. |
| Microsoft Store | Explicitly listed in Plarium's July 2026 anniversary announcement. [O] ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) | Do not infer Xbox console availability from a Microsoft Store listing. |
| Cross-platform ecosystem | Officially supports mobile/desktop play and shared progress using the appropriate account link. [O] PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US) · ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · DESK [7](https://mecharena.game/mech-arena-pc-mac/) | Crossplay does not establish identical input ergonomics or prove input-separated queues. |

Plarium announced a **global mobile launch on 12 August 2021** with multilingual support. The India-specific Google Play country page and Indian Apple storefront are accessible at this research cut-off. This is evidence of public regional listing, not a guarantee that every Indian device/account—or every country worldwide—is eligible to install the latest build. A complete authoritative country allowlist was not established. [O; S-unknown for exhaustive coverage] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · INPLAY [101](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en&gl=IN) · INAPPLE [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228)

Age labels and legal verification must be separated. For example, the inspected India Google listing shows a 7+ rating while the Indian Apple listing shows 13+. Separately, 2026 support FAQs describe adult-confirmation requirements for certain new store accounts in selected US states. Those requirements do not establish a universal global 18+ rating. Tournament organizers must check platform rules, event eligibility, applicable law, and guardian/consent requirements rather than copy one global age number. [O for listings/verification; S-recommendation] INPLAY [101](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en&gl=IN) · INAPPLE [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228) · AGEAPPLE [139](https://mecharena-support.plarium.com/hc/en-us/articles/28973369510172-Age-Verification-FAQ) · AGEPLAY [140](https://mecharena-support.plarium.com/hc/en-us/articles/28974098136220-Age-Verification-FAQ)

## 1.3 Ownership and operational identity

Plarium remains the named game developer/publisher. Its corporate parent is **Modern Times Group (MTG)**: MTG's acquisition of Plarium was announced in November 2024 and closed on **12 February 2025**. Corporate ownership, game publishing identity, and the individual teams operating Mech Arena are different organizational levels. Neither the parent's portfolio nor Plarium's other games should be used as proof of Mech Arena's technical stack. [O; final caution S] MTG [1](https://www.mtg.com/midcore-district/plarium/) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/)

Plarium's broader infrastructure includes **Plarium Play**, its direct-to-consumer desktop distribution platform, and **GoGame**, a proprietary marketing platform. Their existence is officially documented at company level. It is not evidence that GoGame hosts combat sessions or that every corporate backend component is used by this game. [O / S-boundary] ANN4 [7](https://company.plarium.com/en/articles/mech-arena-celebrates-its-4th-anniversary/) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/)

## 1.4 Systems-oriented evolution

| Period | Verified milestone or documented state | Architectural significance |
|---|---|---|
| August 2021 | Global iOS/Android launch. [O] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) | Establishes short session PvP, configurable mechs, team modes, and persistent progression. |
| August 2022 | Plarium Play desktop launch with cross-progress instructions and Denuvo installation disclosure. [O] PC [2](https://forum.plarium.com/en/mech-arena/854_news/31666_mech-arena-is-live-on-plarium-play/) | Expands device/input ecosystem and introduces a documented desktop anti-cheat dependency. |
| November 2022 | Clans announced. [O] CLANOUT [1](https://plarium.com/forum/en/mech-arena/854_news/41890_clans-are-here/) | Adds persistent group identity and aggregate competition outside a single match. |
| August 2023 | Gear Hub made available to everyone. [O] HUBOUT [7](https://plarium.com/forum/en/mech-arena/854_news/42409_gear-hub-is-out/) | Shifts content access to sequential tier acquisition/rank investment rather than treating XP as the universal equipment-unlock path. |
| June 2024 | Detailed developer account of the map pipeline and interactive moving objects. [O] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) | Documents dynamic geometry, navigation, synchronization, testing, and toolchain design. |
| July–August 2025 | Version 3.330 introduces Showdown; August FAQ confirms ordinary 2v2 removal. [O] APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) | Changes small-team combat and concentrates matchmaking populations. |
| November 2025 onward | Multi-stage rebalance and seasonal Modifier plan announced. [O-announced] REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) | Formalizes roster refresh and stated balance communication practices. |
| February–April 2026 | Battle Pass changes; Showdown 2.0; Mod rework; new Tournament format. [O] PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) | Reconfigures effort budgets, survivability progression, and competitive reward flow. |
| May–June 2026 | Tournament pacing/reward correction, then increased A-Coin rewards and bot adjustments announced. [O-announced] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/) | Demonstrates economy and matchmaking being tuned together. |
| July–August 2026 | Content Trial discontinuation for existing testers, with a limited new-player experiment retained. [O] TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) | A tested feature is not equivalent to a universally released permanent mode. |
| August–September 2026 | Release family 3.470, Pilots' Club, sixth rebalance wave, MAQC anniversary season. [O/C] V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) · REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) · MAQCLIVE [144](https://maqc.mecharenadev.com/) | Current live-service snapshot, with separate client, event, and organizer calendars. |

This chronology is intentionally selective: it tracks structural changes rather than every content drop. Pre-global availability existed, but this dossier does not assert an exact first beta/soft-launch date without a sufficiently strong release record. The global launch date is not the date of every regional storefront's first appearance.

## 1.5 Audience and scale

The launch statement explicitly targeted an accessible pick-up-and-play experience for casual shooter fans as well as more dedicated competitors. The product supports several different motivations: short combat sessions, gear/build experimentation, social play, resource optimization, leaderboard pursuit, and collection. These are functional audience segments, not measured demographic shares. [O for stated positioning; S-analysis for segmentation] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

Plarium reported **more than 80 million lifetime downloads** at the fourth anniversary in August 2025. That number is a dated publisher-reported reach indicator. It is **not** current monthly active users, concurrent players, unique human opponents, retention, or paying users. No sufficiently verifiable current MAU, concurrency, mode population, revenue split, or payer-conversion series was established for this dossier. [O / S-unknown] ANN4 [7](https://company.plarium.com/en/articles/mech-arena-celebrates-its-4th-anniversary/)

---

# 2. High-level system architecture and loops

## 2.1 Six interacting product layers

The following is an **analyst's logical architecture**, not a claim about Plarium's microservices or database layout. [S-model grounded in the cited feature documentation]

| Layer | Main responsibilities | Outputs and dependencies |
|---|---|---|
| Identity and access | Account binding, device compatibility, profile, age/store eligibility, support access. | A persistent account entitled to access available features. ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · ID [134](https://mecharena-support.plarium.com/hc/en-us/articles/26835074933532-What-is-Plarium-ID) · SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) · AGEAPPLE [139](https://mecharena-support.plarium.com/hc/en-us/articles/28973369510172-Age-Verification-FAQ) |
| Collection and configuration | Inventory, Gear Hub, ranks/levels, energy constraints, pilots/implants, Mods, presets. | A legal and competitively meaningful battle loadout. HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) |
| Session and combat | Mode selection, matchmaking or private lobby, spawn rules, movement, weapons, abilities, objectives, scoring. | Match outcome and performance events. CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) |
| Progression and reward | XP, RP, TRP, crates, objectives, achievements, pass milestones, first clears. | Currency/resource awards, unlocks, and new goals. PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) |
| Social and organized play | Friends, premades, clans, communication, community competitions. | Repeated teammates, coordination, reputation, player-created goals. TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · DISCORD [5](https://discord.com/servers/mech-arena-official-542314937624690688) · MAQC [4](https://maqc.mecharenadev.com/rules) |
| Live operations and commerce | Timed events, seasonal rules, balance changes, offers, store gifts, loyalty programs. | Updated incentives and rule context across all other layers. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) · STORE [1](https://store.plarium.com/en/mech-arena/) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) |

![Figure 1. Logical product architecture and reinvestment loop](assets/architecture.svg)

*Figure 1 — A conceptual product map. Arrows represent documented functional relationships, not network calls or an observed service topology. [S-model] Sources: PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)*

## 2.2 The loadout as a constrained strategic portfolio

A hangar can contain up to **five mechs**. Each mech can carry up to **two weapons** and a **pilot**; pilots carry compatible implants, while mechs have their own specialized Mod slots. The sum of weapon energy requirements must fit the mech's energy capacity. Gear selection is therefore constrained rather than an unlimited stacking of all owned content. [O] MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · WEAPON [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods)

A useful legality constraint is:

```text
weapon_energy_left + weapon_energy_right <= mech_energy_capacity
```

This restates the equipment rule; it is not a formula for damage, Squad Power, matchmaking, or a server validation implementation. [O rule / S formalization] MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · WEAPON [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons)

The official mech model distinguishes Scout, Attacker, Tank and Support roles and describes HP, speed, ability cooldown and an approximate Power rating. Weapon properties include type, energy cost, perk, damage per shot/magazine at ideal range, fire rate **excluding reload**, optimal/max range, magazine capacity, reload, accuracy and splash radius. These are different dimensions: magazine damage is not sustained damage per second, and maximum range is not the same as the range for maximum damage. [O properties; S analytical distinction] MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · WEAPON [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons)

Several dimensions must remain separate:

- **Grade/rarity** describes an item's fixed category. It is not increased by ordinary leveling. [O] GRADE [110](https://mecharena-support.plarium.com/hc/en-us/articles/12554603916444-Mech-or-Weapon-Grade)
- **Level** and **rank** are upgrade coordinates. Rank increases can expand a mech's usable energy and enable further progression; grade is not simply another name for either. [O] OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · UPGRADE [150](https://mecharena-support.plarium.com/hc/en-us/articles/12739688618780-How-can-I-increase-Squad-Power) · GRADE [110](https://mecharena-support.plarium.com/hc/en-us/articles/12554603916444-Mech-or-Weapon-Grade)
- **Pilot progression** and **implant progression** have their own resources and restrictions. [O] PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants)
- **Mods** add survivability and are mech-specific. Their upgrade ceiling is tied to the host mech's rank under the April 2026 rework. [O] MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/)
- **A preset** is a saved configuration, not a separate inventory or duplicate ownership grant. The same owned equipment can be configured across different presets. [O] PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets)

Further build constraints matter at the system level. A pilot has a fixed specialization and can be paired with only one mech within a hangar; duplicate copies of a pilot cannot be owned. Matching the weapon type to the pilot's Innate Skill enables the specialized weapon-damage bonus. Implant capacity is rarity-dependent: two slots on Rare pilots, three on Epic, and four on Legendary/Limited Edition. Multiple implants affecting the same statistic cannot be stacked. An implant's **effective level** is capped by its host pilot's rank, even if its owned level is higher. [O] PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants)

Implant **Autofill** selects suitable available implants for maximum displayed Power enhancement when a paired pilot, equipped weapon and free slot are present. It should not be assumed to solve map- or mode-specific competitive optimization. Mods use four specialized slot categories and derive their HP from a percentage of the mech's maximum HP, but their placement is mech-specific rather than pilot-bound. [O features; S optimization caveat] IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods)

**Strategic implication [S-analysis]:** a strong hangar needs coverage, coherence, and enough depth to remain effective after its preferred opening choice is unavailable. Maximum displayed power alone does not specify range coverage, objective mobility, shield interaction, cooldown alignment, or resilience across different maps. Official loadout guidance recommends balanced ranks/levels/rarities and mode-specific presets, but the exact competitive value of any configuration still depends on the ruleset and opposition. LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

## 2.3 Nested loops

| Loop | Player action sequence | Typical feedback | Design interpretation |
|---|---|---|---|
| Micro-combat | Read space → aim/move → shoot or use ability → respond to damage and cooldowns. | Damage, destruction, control-point state, radar, score. [O] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · CONTROL [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575581245340-Controls-and-Battle-Settings) · CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) | A repeated information–decision–execution loop. [S] |
| Life/round | Choose a mech → deploy → gain value → die, survive, or finish round → choose again where permitted. | Remaining usable hangar; round score; positional reset. [O/C] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) | Loadout selection and execution form one strategy, not separate minigames. [S] |
| Match | Enter eligible queue/lobby → compete → resolve outcome → receive applicable progression. | RP/TRP, XP, medals, event credit, mode rewards. [O] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) | A bounded unit that can be replayed or scheduled. [S] |
| Session | Check tasks/limits → select goals and mode → play several matches → claim/reinvest → stop. | Milestones, exhausted reward budgets, upgrade availability. [O mechanics] OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) | Session length is shaped by reward clocks as well as available time. [S] |
| Daily/seasonal | Return for renewed attempts/objectives → progress events/pass/ranks → claim rewards. | Fresh tasks, league movement, season-end outcomes. [O] OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) | Several clocks create reasons to return without all resetting together. [S] |
| Long-term | Build collection → specialize/upgrade → enter harder competition → adapt to new rules/content. | Greater access and capability; new strategic demands. [O mechanics] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) | Persistent progression and shifting competition prevent a single permanent solved state. [S] |

## 2.4 Reward routing is conditional, not universal

A battle result is not one universal reward number. It can feed several independently gated outputs: account XP, ordinary RP, Tournament TRP, Combat/Victory Points, event objectives, achievements, Showdown's daily track, or a PvE first-clear reward. **Mode eligibility, outcome, performance, caps, ownership, and current event rules** determine which routes are available. Custom Matches and Onslaught are particularly important exceptions. [O; architecture synthesis] POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

```text
eligible battle result
  ├─ account progression, subject to XP rules
  ├─ ordinary ranking, where applicable
  ├─ Tournament ranking/rewards, only in its format
  ├─ point-to-crate routes, subject to mode and caps
  ├─ objective predicates, only when the event permits
  └─ mode-specific rewards, such as Showdown or first clears
```

**[S-model]** An analytics system should represent the result as a vector of independently qualified outputs, not equate “win,” “MVP,” “got A-Coins,” and “advanced an objective.” It should also distinguish **earned**, **claimable**, **claimed**, and **delivered to Inbox**. These can occur at different times. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · INBOX [131](https://mecharena-support.plarium.com/hc/en-us/articles/16444499048476-Inbox-and-News) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club)

## 2.5 Engagement budgets and stopping points

Ordinary play and monetization interact through multiple budgets. Standard battle XP is capped; Combat/Victory Points have division-based limits; Tournament has an entry-attempt budget; Showdown has a reward-bearing-match budget followed by unlimited additional play for RP/XP. These are not one shared energy system. [O] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match)

**[S-analysis]** This creates different rational stopping rules:

- A progression-focused player may stop when a relevant reward budget is exhausted.
- A competitive player may continue ordinary play for rank or practice, where permitted.
- A Tournament player with no attempts cannot simply substitute extra queue volume in that same daily format.
- A social player may prefer unrewarded Custom Matches because coordination, testing, or tournament preparation is the actual goal.
- A player chasing a timed milestone may value an action differently from someone maximizing long-run currency efficiency.

---

# 3. Complete player journey

## 3.1 A progression graph, not a fixed number of days

Players do not necessarily experience the same “day 1 / day 7 / day 30” path. Win/loss results influence division access; XP tracks another set of unlocks; resources and purchases influence hangar development; events can grant content ahead of the normal Gear Hub tier; feature tests can be cohort-restricted. The journey below is therefore organized by **capability and access milestones**, not promised calendar completion times. [O underlying gates; S journey model] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · TRIALTEST [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/)

![Figure 2. Player journey with parallel progression tracks](assets/journey.svg)

*Figure 2 — Progression branches overlap. XP, rank, inventory development, social organization, and organized competition are independent but interacting paths. [S-model] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · MAQC [4](https://maqc.mecharenadev.com/rules)*

## 3.2 Stage-by-stage experience

| Stage | Systems and activities encountered | Learning burden and evolving goals | Evidence |
|---|---|---|---|
| First launch | Download supported client; enter tutorial; begin with a small hangar; create/link a recoverable account connection when available. | Understand movement, aim/fire, ability use, reload and control-point interaction. Avoid losing an unlinked account. | Tutorial sequence is community documented; account binding is official. [C/O] BEGINWIKI [3](https://mech-arena-robot-showdown.fandom.com/wiki/Beginner's_Guide) · ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) |
| Tutorial / first matches | Basic combat instruction and initial CPC experience; hangar introduction and equipment interaction. | Separate shooting success from objective success; learn the difference between owning a mech and deploying it. | [C/O] BEGINWIKI [3](https://mech-arena-robot-showdown.fandom.com/wiki/Beginner's_Guide) · BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) |
| Early game | Initial League Division climb, additional hangar slots, Gear Hub objectives, recurring objectives, login rewards, progressively exposed modes. | Build a functional multi-mech roster, read energy constraints, distinguish Credits from A-Coins and XP from RP. | [O] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) · LOGIN [118](https://mecharena-support.plarium.com/hc/en-us/articles/12559453400732-Daily-Login-Program) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) |
| Developing / mid-game | Pilots and implants, Rank-3 Mod access, mode specialization, clans/premades, deeper Gear Hub progression, time-limited events. | Manage several upgrade-resource bottlenecks; understand matchmaking exposure and team roles. | [O] PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) |
| Established / late game | Multiple presets, five-mech Tournament eligibility, higher equipment tiers, more demanding ranked and Showdown opposition. | Improve full-hangar consistency, map adaptation, target selection and performance under gear constraints. | [O mechanics; S skill model] PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) |
| Persistent endgame | Season Divisions, Tournament rank optimization, mature hangar development, continuing events/collection and Endless Path. | Decide whether to pursue ranking, collection, efficient progression, social play, or mastery. | [O mechanics; S segmentation] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) |
| Competitive endgame | Coordinated squads, organized Custom Matches, MAQC or other published community competitions. | Scheduling, roster legality, power disclosure, evidence capture, repeatable team strategy and rules compliance. | [O/C] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) |
| Return after a break | Re-check client requirements, new systems, changed rewards and mode availability; relink the correct account; examine returning-player promotions if offered. | Unlearn obsolete assumptions before spending resources or registering for competition. | [O mechanics; S procedure] SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) · ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · PROMO [130](https://mecharena-support.plarium.com/hc/en-us/articles/15036191425308-What-is-a-Promo-Code) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) |

“Endgame” is an analytical description of player goals, not one official unlock. Reaching the final XP milestone, reaching League Division 1, owning mature gear, and qualifying for a community event are four different achievements. A player can advance in one without completing the others. [S-analysis grounded in separate official gates] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · MAQC [4](https://maqc.mecharenadev.com/rules)

## 3.3 Confirmed gate matrix

| Gate | What it enables | Qualification |
|---|---|---|
| Initial tutorial / beginning | CPC is the first battle mode taught and available. [O/C] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · BEGINWIKI [3](https://mech-arena-robot-showdown.fandom.com/wiki/Beginner's_Guide) | Exact screen order and tutorial skip behavior can vary; this is not a current-client walkthrough recording. |
| Division 9 | 5v5 Deathmatch. [O] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) | Also a prerequisite for Modifiers through the DM unlock condition. |
| Tutorial complete + 5v5 unlocked | Modifiers feature. [O] MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers) | Actual active effects remain event/ruleset-dependent. |
| Division 8 | Create or join a clan. [O] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) | Clan-specific acceptance criteria may add social restrictions. |
| Division 7 + at least four mechs | Hangar Showdown. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) | Showdown league assignment is a separate equipment-based parameter. |
| Division 5 | Custom Matches. [O] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) | Host mode/map availability is constrained to what the client offers. |
| Division 4 + a five-mech selected hangar/preset + attempts | Reworked Tournament access. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) | FFA additionally requires exactly five active mechs and no premade team. |
| 1,000 account XP | Pilot Access in the dedicated Progress Path guide. [O] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) | The official beginner guide describes meeting a pilot during tutorial; do not turn that into a universal contradictory first-pilot timeline. |
| 10,000 account XP | Squad Presets; up to three free presets. [O] PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) | The Tournament wording “preset” does not prove every entrant must first unlock multiple-preset management. Verify the actual eligibility screen. |
| Mech Rank 3 | Current Mod access for that mech. [O] MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) | Old 30,000-XP / Rank-6 cohort guidance is superseded. |
| League Division 1 | Season Divisions. [O] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) | Seasonal reset is not a reset of owned equipment or the permanent beginner ladder. |
| 326,400 account XP | Endless Path, with a random reward per additional 6,400 XP. [O] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) | This is a progression-reward loop, not an unlimited instant currency faucet. |
| Tutorial complete + linked Plarium ID for website membership/claims | Pilots' Club. [O] CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) | Points may accumulate before joining; Pilot Points are not Pilot XP or Pilot Marks. |
| Specific PvE level equipment criteria | Access to that Onslaught level. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) | Trial variants may provide prescribed content; do not generalize that to every standard level. |

The beginner's total hangar-slot expansion is economically meaningful: extra slots require Credits and A-Coins, and a full five-mech roster is necessary for the current Tournament format. Specific slot prices and promotion-dependent offers should be read in the live client, not hard-coded from an old guide. [O] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

## 3.4 Learning curriculum and friction points

**[S-analysis / recommendation]** A useful onboarding curriculum progresses through five layers:

1. **Execution:** move and aim independently, understand range, fire/reload rhythm, and ability cooldowns.
2. **Objectives:** learn why holding territory or preserving a round lead can be more valuable than chasing one kill.
3. **Build coherence:** understand energy compatibility, complementary ranges, mobility/survivability, and the depth of the whole hangar.
4. **Economy and rules literacy:** identify the next bottleneck, read caps and event predicates, and distinguish the several ranking systems.
5. **Coordination:** communicate intentions, trade pressure, select compatible roles, and comply with organized-play procedures.

This curriculum is derived from the interaction between official combat guidance, resource rules, mode constraints, and organizer procedures—not from an internal onboarding design document. BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · MAQC [4](https://maqc.mecharenadev.com/rules)

Typical friction hypotheses include premature investment in an isolated high-power asset, insufficient depth for restricted formats, overspending to complete an event whose prize is worth less to that player than its marginal cost, and interpreting a new matchmaking pool as a direct punishment for upgrading. The first issue is explicitly warned about in official loadout guidance; the broader behavioral effects require player research to measure. [O for warning; S for hypotheses] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

## 3.5 Branching endgame identities

**[S-analysis]** There is not one optimal endgame because players optimize different objective functions:

- **Rank climber:** maximize successful high-quality ranked attempts and repeatable performance.
- **Tournament specialist:** optimize the active format, daily attempt use, and rank-dependent rewards.
- **Organized-team competitor:** maximize compliant, coordinated series wins against scheduled opponents.
- **Resource optimizer:** compare acquisition routes, upgrade bottlenecks, and opportunity cost.
- **Collector/customizer:** pursue breadth, aesthetics, milestones, and event exclusives.
- **Social regular:** prioritize familiar teammates and clan/community identity.
- **Researcher/creator:** test hypotheses in controlled Custom Matches and explain the results responsibly.

These roles can overlap. Their existence as plausible play styles follows from the available systems; their population shares, spending patterns, and retention effects are not publicly established here. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · MAQC [4](https://maqc.mecharenadev.com/rules) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · ACHIEVE [119](https://mecharena-support.plarium.com/hc/en-us/articles/12575503767708-Mech-Achievements) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match)


# 4. Mode-by-mode operational specifications

## 4.0 Mode taxonomy and availability

A **combat ruleset** defines what happens in battle. A **queue/lobby context** defines how participants enter. A **competitive wrapper** adds ranking, attempts, and rewards. An **event modifier** changes selected parameters. Treating all four as equivalent “modes” obscures important differences. [S taxonomy based on official mode descriptions] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers)

| Experience | Classification and documented status | Players / structure | Main reward context |
|---|---|---|---|
| Control Point Clash (CPC) | Current team combat ruleset. [O] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) | 5v5; territorial Influence plus elimination victory. | Quick Match progression; Tournament wrapper when included. |
| 5v5 Deathmatch | Current team combat ruleset. [O] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) | Two five-player teams; timed rounds. | Quick Match progression; Tournament wrapper when included. |
| Free-For-All (FFA) | Current, Tournament-only individual ruleset. [O] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) | Ten participants; five-minute kill competition. | Tournament attempts, TRP and applicable rewards. |
| Hangar Showdown | Current small-team format, originally beta; substantially reworked in April 2026. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) | 2v2; successive single-mech rounds; temporary maximum ranks/levels. | Ten daily reward-track matches; further RP/XP play. |
| Onslaught | Current solo PvE mode/event structure. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) | One human against AI waves or a target. | Level first-clear rewards. |
| Onslaught Trial | Event-specific trial variant, still promoted in 3.470. [O] V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · INAPPLE [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228) | Prescribed trial experience within the PvE/event family. | Event/level-specific rewards. |
| Custom Match | Current player-hosted lobby context. [O] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) | Invited players; configurable bot fill, available mode and map. | No XP/reward/objective/achievement farming. |
| Legacy 2v2 Deathmatch | Removed from the ordinary public mode offering. [O] HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) | Former small-team Deathmatch format. | Historical rules; not a current daily queue assumption. |
| Content Trial / Trial Mode test | Withdrawn from existing testers from 3 August 2026; limited new-player experiment retained. [O] TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) | Restricted testing environment. | Not a verified universal permanent reward mode. |
| Tournament / Team Match / Quick Match | Entry and competition contexts, not three additional independent combat rulesets. [O/S taxonomy] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) | Depend on the active mode. | Different eligibility, ranking, and reward paths. |

A storefront or older official overview listing 2v2 does not override the explicit removal FAQ. Similarly, “Trial Mode discontinued” does not mean Onslaught Trial was removed. These naming collisions are among the most consequential errors in secondary summaries. HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/)

## 4.1 Control Point Clash

### Purpose and core rules

CPC emphasizes spatial control and team coordination rather than kill score alone. Two teams of five fight on a map with **three or five control points** for up to **five minutes**. Point ownership is shown as blue for the player's team, red for the opponent, and grey for neutral. Holding captured territory generates Influence. [O; continuous holding interpretation also documented by independent gameplay accounts] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · LEVELWIN [7](https://www.levelwinner.com/mech-arena-robot-showdown-beginners-guide-tips-tricks-strategies/)

A team wins by one of three conditions:

1. Reaching **100 Influence** first.
2. Having more Influence when time expires.
3. Destroying all of the enemy team's available mechs. [O] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash)

Capturing many points is a means to accumulating Influence, not a separate “most captures wins” rule. A team can also win by elimination without finishing the Influence race. Exact capture timing, per-point accrual rates, contested-point behavior, and an exhaustive tied-at-timeout rule were not established by the dedicated support article. Do not invent a universal seconds-per-capture constant. [O rules / S-unknown details] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash)

### Spawning and life economy

Independent gameplay documentation describes a team base spawn and the ability to respawn at controlled points. Players select another available mech after a normal destruction; the ordinary finite hangar is not FFA's automatically recycling roster. This creates an interaction between terrain ownership, reinforcement location, and remaining combat depth. [C; strategic consequence S] LEVELWIN [7](https://www.levelwinner.com/mech-arena-robot-showdown-beginners-guide-tips-tricks-strategies/) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes)

The engineering account confirms that spawn points are explicitly authored with team, type, and identifier parameters. It does not establish that every CPC point or every map uses identical spawn-safety rules. [O] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

### Scoring, progression, and rewards

CPC's dedicated guide lists XP, non-Tournament Combat Points, Victory Points for a win, and winning RP. Broader RP rules also describe losses/demotion; limits and eligibility still apply. When CPC is inside a Tournament, Tournament attempts/TRP/rewards are additional wrapper rules, not an alternative territorial win condition. [O] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

The top three **mechs** by contribution are shown as MVPs; one player can occupy more than one MVP position. Contribution recognition is not equivalent to the team's territorial win condition. [O] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash)

### Strategic operating principles

**[S-analysis]** Evaluate an action by its effect on the remaining win race:

- Secure enough territory to control the Influence rate before pursuing low-value distant kills.
- Defend reinforcement routes and avoid leaving every captured point undefended.
- Use mobility for rotation and threat; use survivability and area control to hold valuable space.
- When ahead near timeout, preserve control and the remaining hangar rather than taking unnecessary trades.
- When behind, identify whether a territorial reversal or an elimination push is more plausible.

These are consequences of the official victory alternatives, map geometry, and finite-life observations, not claims about a particular competitive item tier list. CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · LEVELWIN [7](https://www.levelwinner.com/mech-arena-robot-showdown-beginners-guide-tips-tricks-strategies/)

**Matchmaking context:** ordinary equipment-sensitive Quick Match or the current Tournament population/rank context. No public CPC-specific team-balancing formula or guaranteed human/bot ratio was established. LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)

## 4.2 5v5 Deathmatch

### Purpose, access, and battle structure

Unlocked at **Division 9**, this mode pits two full five-player teams against one another for kills over multiple rounds. Each round has a **two-minute** timer. The team with more enemy mech destructions wins the round; destroying the entire enemy roster can also end it. The first team to win **two rounds** wins the battle. [O] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch)

If kills are tied at two minutes, the round gets **30 seconds of overtime**. If still tied, the round is a draw. Official beginner material describes up to three rounds, while the dedicated article emphasizes “first to two.” Community documentation records an overall draw when teams split wins and the remaining round is tied. The reviewed sources do not completely specify every possible multi-draw sequence; an organizer should test edge cases rather than impose a made-up sudden-death rule. [O/C; residual details unresolved] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes)

### Respawns and round reset

Community mode documentation describes exhausting one's available mechs within a round and waiting for the next round. The official article confirms the same mech can contribute across more than one round and aggregates its performance for MVP purposes. Thus the normal round cycle differs from Showdown, which requires a new mech each round even if the previous one survived. [O/C] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown)

The exact timing of spawn protection, reconnect restoration, and every ability/cooldown reset is not published in the cited Deathmatch guide. Those should remain explicit implementation unknowns rather than copied generic shooter assumptions.

### Scoring and reward context

**Kills decide rounds; round wins decide the battle.** Total kills over the entire battle are not a replacement for the round-win rule. MVP recognition considers a mech's contribution over all rounds in which it was used. Quick Match point/XP and ordinary ranking rules apply in their documented contexts; Tournament entry and reward rules apply when Deathmatch is the active Tournament format. [O] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

### Strategic operating principles

**[S-analysis]** Deathmatch makes life trades, timing, and lead preservation central:

- Distinguish a profitable kill trade from merely increasing personal damage.
- Establish mutually supporting ranges and avoid isolated entries into crossfire.
- Use reload and ability windows to synchronize pressure.
- When ahead late in a round, reduce unnecessary exposure; when behind, coordinate a realistic conversion attempt.
- Between rounds, adapt to the map and opponents, rather than treating each life as an independent duel.

Team utility may not map perfectly onto personal kill count or battle-score incentives. The mismatch is an analytical risk to evaluate, not evidence that the game's scoring ignores all support contribution. DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · AWARD [6](https://mecharena-support.plarium.com/hc/en-us/articles/12642067896860-Battle-Awards) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 4.3 Free-For-All

### Purpose and access

FFA is a **ten-participant**, every-player-for-themselves mode with **no teams and no assists**. It is available **only within Tournament**. Entry requires Tournament access at **Division 4** and **exactly five equipped mechs** in the active hangar. Five player slots in a premade squad are not the same requirement as five mechs owned/equipped by one player. [O] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

### Exact documented scoring contract

| Rule | Documented behavior |
|---|---|
| Duration | Five minutes, with no overtime. |
| Final blow | Adds one kill to the credited player's score. |
| Voluntary mech change | Destroys/replaces the current mech and deducts one kill; score cannot fall below −5. |
| Match winners | Top three players by kill result at the end. |
| Equal final result | Priority goes to the player who reached the kill count first. |
| Kill healing | The current mech restores 30% of maximum HP per kill, cannot exceed maximum HP, and can trigger repeatedly. The guide includes an explicit exception for HP-boosting skills; it does not publish a full stacking formula for every bonus. |
| Leader designation | At least three kills and the highest kill count. Leader receives a visible marker and global UI notification. |
| Losing the lead | Another player must surpass the score by at least one, or self-destruction can remove points/status. |
| Roster recycle | A mech cannot be reused until all five mechs in the battle group have been spawned; the hangar then refreshes for another cycle. |
| Information | Enemies are highlighted from spawn, subject to normal stealth exceptions. |
| Assists | Assist points and assist-related Battle Achievements are disabled. |

**All rules in this table: [O], dedicated FFA guide.** FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA)

### Three non-equivalent outcome layers

1. **Player placement:** the top three are match winners and receive the corresponding win recognition. [O] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA)
2. **Tournament resource eligibility:** the May 2026 policy explicitly awards FFA A-Coins to the top five, despite the top-three match-win definition. The June notice increases reward quantities; it does not publicly revoke that top-five distinction. Read the live reward panel for amounts and later changes. [O-announced/current documented policy] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/)
3. **MVP presentation:** the top three **individual mechs** are selected by Battle Score using kills, damage, and achievements. They are not simply the three highest-placing players. Per-lifecycle achievements reset on a new spawn. [O] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA)

### Strategy and progression consequences

**[S-analysis]** FFA rewards independent kill conversion and survival. Damage that does not secure the final blow has different scoreboard value from team modes. Kill healing can extend a productive life, while the visible leader marker attracts pressure. Opponents are both threats and competing claimants on finishing opportunities. The mandatory five-mech cycle creates a cost to over-relying on one preferred build, and voluntary switching has an explicit score cost. FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA)

A top-five finish can be economically successful without being a match win; an impressive MVP mech can appear in a lower-placing player's hangar; a high damage total need not imply a high kill placement. These distinctions should be reflected in guides, reward simulators, and tournament commentary. [S-analysis of O rules] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

FFA consumes the current Tournament's daily attempt budget. There is no documented unrestricted public FFA practice queue, no legal premade-team entry for FFA, and no basis to assume a queue guarantees nine other humans rather than a mix containing bots. FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

## 4.4 Hangar Showdown

### Purpose and structure

Showdown is a **2v2** mode unlocked at **Division 7** with **at least four mechs**. Matches are described as up to five rounds, with the first team to win three taking the match. Each round lasts **90 seconds** and requires selection of a **new mech**, regardless of whether the last selection survived. The primary round goal is destroying the enemy mechs. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown)

Equipment performs at its maximum rank/level **during the battle**. This is temporary normalization, not a permanent inventory upgrade and not a grant of every unowned item. The existence of equipment-based leagues and restrictions also means Showdown is not a universally identical-loadout esports environment. [O; latter distinction S-analysis] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/)

### League-dependent rules

The Showdown league is separate from ordinary RP divisions and is determined by mech rarity/grade and rank-star characteristics. The dedicated guide describes four leagues with the following equipment restrictions. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/)

| Showdown league, using the guide's numbering | Equipment layers permitted |
|---|---|
| 4 and 3 | No pilots, implants, or Mods. |
| 2 | Pilots and implants introduced; Mods not listed as available. |
| 1 | Pilots, implants, and Mods permitted. |

**Caution:** the same article gives a “higher league” reward-multiplier example that conflicts with this numbering, and its illustration uses an older named-league display. The March 2026 update also changes star requirements and bot populations. This dossier therefore does **not** publish an invented consistent table of star thresholds or reward multipliers. Use the live league card for the actual threshold and permitted layers. [O-source conflict] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/)

### Daily reward economy

The first **ten daily matches are free** and contribute to a daily Showdown Battle Point track. Rewards can include crates, keys, Credits, Mod Parts, and point boosters; track progress and score refresh daily. After these ten matches, play is unlimited but earns only **RP and XP** under the dedicated support wording. The earlier “five free, more for A-Coins” era is not the current documented format. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/)

The April update also introduces **bot control of AFK allies until they return**, corroborated by storefront release history. This is not evidence that every mode has identical reconnect/takeover behavior. [O] HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228)

### Team formation and unresolved edge cases

The August 2025 FAQ said friend teaming was being explored and tested, not released. No subsequent confirmation of universal Showdown friend-premade support was established in the reviewed sources. Do not promise that ordinary Team Match functionality automatically applies here. [O-historical statement; S-current unknown] HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates)

Public rules leave several organizer-relevant details insufficiently explained: timeout round adjudication with survivors; draw sequences; how a four-mech entry interacts with a possible fifth round; precise current star thresholds; and cross-league matching behavior. The historical beta FAQ acknowledges cross-league matching and ongoing tuning but does not establish the exact current tolerance. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/)

### Strategic operating principles

**[S-analysis]** The sequence of selections matters as much as the first matchup. Players must preserve complementary options for later rounds, coordinate with one ally, adapt to revealed enemy choices, and build within the current league's layers. Temporary maxing makes lower-upgraded owned gear more testable, but ownership breadth and format restrictions continue to matter. Avoid treating an early-round win as proof that the remaining hangar is favorable. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 4.5 Onslaught

### Purpose and rules

Onslaught is **solo PvE**: one player fights exclusively against AI-controlled bots **without teammates**. The objective is to eliminate incoming waves or a particular target. Levels impose equipment requirements, and access may require owning a specified mech or weapon. The Onslaught Shop offers content/resources intended to help clear levels. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

There is no single universal public Onslaught round length, wave count, or enemy table that applies to every event/level. Read the active level's conditions. The broader official overview also mentions campaigns and a leaderboard, but the dedicated guide does not define a universal PvE rating or leaderboard formula; any displayed event board needs its own rules rather than being equated with ordinary RP. OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) Calling the mode co-op, a multiplayer survival raid, or an offline campaign is incorrect under the current support description. [O / S-unknown for universal parameters] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · OFFLINE [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline)

### Rewards and exclusions

Rewards are awarded for **first completion of a level**, with further clears of different levels advancing the reward opportunity. The dedicated guide explicitly excludes:

- RP;
- Battle/Combat and Victory Points;
- account XP;
- medals;
- ordinary objective completion;
- Battle Log and Player Profile result recording. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

A level's own clear condition and first-clear reward are not the same thing as a generic “win battles” or “deal damage” Event Objective. Repeating a cleared level should not be modeled as an unlimited first-clear reward farm. [S interpretation of O exclusions] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

### Strategic and design roles

**[S-analysis]** Onslaught shifts the challenge from reading human intent to understanding encounter composition, timing, survivability, target priority, and loadout gates. It creates an alternate activity and a context for demonstrating content. Its equipment gates and dedicated shop also connect challenge access with acquisition. These are system-level observations, not a guarantee of its fairness, difficulty curve, or conversion effect. PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

## 4.6 Onslaught Trial

Official version notes and the September storefront event panel continue to promote **Onslaught Trial** as a way to try featured content and earn rewards. It belongs to the limited-event/PvE family and must be distinguished from the separate Content Trial experiment discussed below. [O] V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) · INAPPLE [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228)

The operational contract is the active trial's prescribed equipment, encounter, availability, and reward panel. The reviewed high-level sources do not establish one permanent universal trial progression, ownership grant, timer, or reward repeatability rule. An offered trial does not imply that the tested content has been permanently unlocked in the account. [S-boundary grounded in official trial framing] V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

**[S-analysis]** A trial helps a player learn handling and ability behavior, but the transfer of that experience to normal PvP depends on rank, pilots, implants, Mods, bots, teammates, and map conditions. It is therefore a demonstration environment, not automatically a controlled estimate of ranked performance. The discontinuation explanation for the separate Content Trial illustrates why that distinction matters. TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/)

## 4.7 Custom Matches

### Purpose and configuration

Unlocked at **Division 5**, Custom Match allows a host to invite friends to either team, distribute a **Match ID**, choose an available mode and map, and configure bots. The lobby offers: [O] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match)

| Setting | Meaning |
|---|---|
| No bots | No AI filling of team slots. |
| Equalize Teams | Adds bots as necessary to make the team counts equal. |
| Fill Teams | Adds bots to every vacant slot. |

Equalize is a **headcount operation**, not equal equipment power, normalized stats, or fair team skill. The host chooses among available client options, not an arbitrary programmable rules engine. “Hosting a lobby” also does not establish that the player's device hosts the combat server. [O configuration; S boundary] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

### Competition and rewards

Custom Matches grant **no XP or rewards** and do not advance **Event Objectives or Achievements**. Their value is practice, experimentation, social play, and independently organized competition. External rewards, such as MAQC's pool, come from the organizer's competition framework rather than the normal Custom Match result screen. [O/C] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQC [4](https://maqc.mecharenadev.com/rules)

The selected underlying combat mode supplies its victory conditions; an external tournament can then add a series result, roster rules, restrictions, and a dispute process. A best-of-three series of CPC matches is not the same as the rounds inside a Deathmatch battle. [S taxonomy grounded in O/C rules] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · MAQC [4](https://maqc.mecharenadev.com/rules)

### Operational use and limitations

**[S-recommendation]** Custom lobbies are the best documented public tool for reproducible rules tests and scrimmages. Record mode, map, bot setting, players/IDs, build versions, all relevant equipment states, and active Modifiers. Change one test variable at a time. Do not assume unrestricted spectator slots, a replay export, pause/restart authority, or a public automation API merely because private lobbies exist. CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) · KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430)

## 4.8 Legacy 2v2 Deathmatch

The original 2v2 mode belonged to the Deathmatch family with a smaller team. It was part of the global-launch offering. The August 2025 Showdown FAQ explicitly states ordinary 2v2 Deathmatch was removed to increase the chance of matching Showdown players against other people, with no return planned at that time. [O-historical/current removal record] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/)

For researchers, preserve legacy 2v2 as its own historical ruleset rather than rewriting old match records as Showdown. The replacement changes rounds, roster reuse, normalization, and reward incentives. Older support cross-links and storefront descriptions are not sufficient to establish a currently selectable public queue or the exact availability of a legacy option inside Custom Matches. [S data-model recommendation] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/)

## 4.9 Content Trial / Trial Mode experiment

The April 2026 test was intended to let a randomly selected subset of players try content before acquiring it, using controlled ranks/loadouts. It was not a universal release of an unrestricted testing ground. [O-experimental] TRIALTEST [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/)

On **29 July 2026**, Plarium announced withdrawal for existing participants beginning **3 August**. The explanation cites powerful bots, fixed equipment, limited experimentation, and an experience that did not accurately reflect real battles. A limited new-player cohort would retain access for further data gathering. [O; publisher explanation, not an independent experiment] TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/)

Thus its status at this cut-off is **discontinued for the previous test population, with a limited experiment retained**, not “available to everyone,” “entirely gone in every account,” or “Onslaught removed.” Future restoration is not confirmed. TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/)

## 4.10 Tournament and entry-context wrappers

Tournament is a time-limited competitive framework around **CPC, 5v5 Deathmatch, and FFA**, with the active mode/map pool set for each competition. It adds eligibility, eight daily starts, TRP, ranks, and rewards. Its full operational specification appears in Section 6. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

**Quick Match** supplies ordinary public play and the non-Tournament Combat Point route. **Team Match** allows friends/clanmates to queue together into eligible formats; a partial team is filled automatically. These labels do not create new territorial or kill-scoring rules. [O; classification S] POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates)

---

# 5. Anatomy of a match

## 5.1 Match lifecycle

![Figure 3. Match state machine with mode-specific life branches](assets/match-lifecycle.svg)

*Figure 3 — Logical state machine reconstructed from published rules. It is not a reverse-engineered client/server protocol. [S-model] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)*

| Stage | What the player/system does | Important distinctions |
|---|---|---|
| Preflight | Check mode access, lineup legality, active events/Modifiers, selected presets, party requirements and attempts. | Rank access is not the same as having enough mechs or the right event equipment. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) |
| Queue or lobby | Public matchmaking forms a battle, or a Custom host selects participants and bot settings. | No evidence that the public algorithm and external tournament pairings are the same process. [O/C] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQC [4](https://maqc.mecharenadev.com/rules) |
| Battle initialization | Load the map/ruleset, form teams or individual roster, present initial deployment. | Authored spawn parameters differ by team and mode. [O] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) |
| Spawn and combat | A player controls one selected mech, using movement, weapons, abilities, information, and objectives. | Five-mech hangar ownership does not mean simultaneously piloting five units. [O/C] MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · BEGINWIKI [3](https://mech-arena-robot-showdown.fandom.com/wiki/Beginner's_Guide) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| Destruction / transition | The current life ends or a mode permits changing selection. | Team modes, Showdown and FFA have different reuse rules. [O/C] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) |
| Round resolution | If the mode has rounds, resolve its timer/kill/elimination condition and prepare the next round. | A round win, match win and external series win are different events. [O/C] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · MAQC [4](https://maqc.mecharenadev.com/rules) |
| Match resolution | Apply the mode's winner/placement rules and calculate applicable performance outputs. | MVP is not universally equivalent to player placement or victory. [O] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| Postmatch | Display outcomes, award eligible resources/progression, update records, and return to the hangar. | Caps and exclusions can produce a valid win with no further reward on a particular track. [O] CAP [8](https://mecharena-support.plarium.com/hc/en-us/articles/12642357164700-I-won-a-battle-but-got-no-rewards-Why) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · INBOX [131](https://mecharena-support.plarium.com/hc/en-us/articles/16444499048476-Inbox-and-News) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) |

## 5.2 Combat information and execution

Official guidance describes separate movement/aiming controls, weapon firing/reload options, ability activation and cooldowns, damage feedback, a timer, and a minimap. The minimap can reveal enemies seen by allies, while stealth exceptions limit visibility. FFA explicitly changes the default information environment by revealing enemies from spawn. [O] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · CONTROL [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575581245340-Controls-and-Battle-Settings) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA)

Position also changes damage potential: the official beginner guide states **1.5× side damage and 2× rear damage**. Those are general directional rules, not a complete final-damage formula. Defensive Mods can interact with bonus side/rear damage, shielding, and base HP; range, weapon behavior, abilities, and temporary effects can further matter. Do not multiply every published percentage together without checking interaction order. [O rules; S warning] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers)

**[S-analysis]** A useful combat model has at least six interacting variables: position/line of sight, information, cooldown/ammunition state, active defenses and status effects, objective urgency, and remaining hangar depth. It is deliberately richer than “higher power wins.” The developer's map account supports the significance of range bands, cover, movement paths, hazards and readable visual/audio signals. ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 5.3 Destruction is not one universal respawn rule

| Context | Normal documented life/selection behavior | Modeling caution |
|---|---|---|
| CPC | Finite hangar selections; controlled points can provide respawn locations. [C] LEVELWIN [7](https://www.levelwinner.com/mech-arena-robot-showdown-beginners-guide-tips-tricks-strategies/) | Do not import FFA recycling. Individual abilities can create exceptions not catalogued here. |
| 5v5 Deathmatch | Mechs used again across rounds; exhausted players wait until the next round in community documentation. [O/C] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) | Exact cooldown and reconnect resets require testing. |
| FFA | All five must be spawned before the hangar refreshes for reuse. [O] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) | Manual switching deducts score; dying and switching are not identical scoring operations. |
| Showdown | New mech each round, even if the previous one survived. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) | Four-mech eligibility and fifth-round behavior remain underdocumented. |
| Onslaught | Encounter-specific solo challenge. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) | Do not assume the PvP respawn model or generic progression. |
| Custom | Inherits selected mode's rules plus configurable roster context. [O] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) | External organizer restart rules do not rewrite the underlying client state machine. |

## 5.4 Scoring namespaces

“Points” is an overloaded word. A reliable report or data model must distinguish:

| Quantity | Scope and role |
|---|---|
| Kills / frags | Mode-level destruction score; central to Deathmatch and FFA. DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| Influence | CPC team's territorial victory currency inside the match. CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) |
| Round wins | Match-level progress in Deathmatch and Showdown. DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) |
| Battle Score / contribution | Performance recognition, MVP and some point/reward calculations. Exact full coefficients are not published in these guides. FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · AWARD [6](https://mecharena-support.plarium.com/hc/en-us/articles/12642067896860-Battle-Awards) |
| Combat Points | Non-Tournament Quick Match participation/performance route to Silver Crates. POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) |
| Victory Points | Win-linked route to Gold Crates, within eligible modes and limits. POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) |
| Ranking Points (RP) | Ordinary League/Season division standing. RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) |
| Tournament Ranking/Rating Points (TRP) | Separate competitive standing inside the reworked Tournament. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| Showdown Battle Points | Daily Showdown reward-track score, not ordinary Combat Points. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) |
| Event / Pass / Achievement Points | A particular objective/milestone system's progress. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · ACHIEVE [119](https://mecharena-support.plarium.com/hc/en-us/articles/12575503767708-Mech-Achievements) |

**[O]** Each row is sourced individually. Labels vary slightly across official copy—for example “Ranking” versus “Rating” for TRP—but the system separation is the important invariant.

## 5.5 Result recognition, record keeping, and anomalies

Battle awards and medals recognize performance dimensions rather than only team victory. FFA has categories including kills, damage, fewest spawns, and time as leader; Showdown medals include round points, total kills, and rounds survived. A profile can therefore show several notions of achievement at once. [O] AWARD [6](https://mecharena-support.plarium.com/hc/en-us/articles/12642067896860-Battle-Awards) · MEDAL [2](https://mecharena-support.plarium.com/hc/en-us/articles/12642305648796-Medals) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA)

Battle History retains the **last twenty battles** in the documented feature. It is a result history, not evidence of a downloadable replay format or arbitrary spectator access. Onslaught explicitly does not enter the normal battle/profile record. [O] LOG [123](https://mecharena-support.plarium.com/hc/en-us/articles/12746581379100-What-is-Battle-History) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

Leaving early may reduce or eliminate ordinary participation rewards; Tournament attempts are consumed when a battle starts. Disconnections, visual synchronization errors and known bugs should not be interpreted automatically as cheating or as a right to a refunded attempt. The official known-issues page itself distinguishes visual/resource issues and spectator-state problems. [O] POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430) · SYNC [127](https://mecharena-support.plarium.com/hc/en-us/articles/27620757593756-Cheater-or-Game-Mechanic)

**[S-recommendation]** For disputes or tests, capture the pre-match configuration, result screen, player IDs, mode/map, client version, local and UTC time, and error screenshots. Preserve originals. An isolated screenshot of a loss, high damage, or unusual kill is not sufficient to identify a hidden algorithm or establish misconduct. BUG [141](https://mecharena-support.plarium.com/hc/en-us/articles/13793527485852-How-to-create-a-good-bug-report) · CHEAT [124](https://mecharena-support.plarium.com/hc/en-us/articles/12865857341724-How-to-report-cheaters) · MAQC [4](https://maqc.mecharenadev.com/rules)

---

# 6. Competitive progression and ranking systems

## 6.1 There are several ladders, not one

| System | Measure | Progression/reset | What it evaluates or unlocks |
|---|---|---|---|
| League Divisions | Ordinary RP. | Division 10 → 1; permanent onboarding progression, although losses can demote. | Mode/feature access and point-cap benefits. [O] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) |
| Season Divisions | Ordinary RP in the seasonal stage. | Unlock after League Division 1; reset to Season Division 10 each Battle Pass Season. | Seasonal standing, Top 500 and documented season rewards. [O] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) |
| Tournament ranks | TRP. | Fifteen rank steps; event-specific progression, with two protected floors. | Rank-dependent rewards and Legend Top 500. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| Hangar Showdown leagues | Mech grade/rarity and rank-star conditions. | Equipment-development dependent, not described as an RP season ladder. | Matching context, equipment permissions and reward parameters. [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) |
| Clan leaderboards | Aggregate inventory power or weekly damage. | Separate Top 100 boards; damage is weekly. | Group prestige, not a documented clan combat MMR. [O] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) |
| Event leaderboard | Event-specific points. | Exists only for that event's duration/structure. | Limited prize positions, not necessarily combat-skill ranking. [O] EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) |
| External organized competition | Organizer pairing, series results, SP brackets and conduct. | Rulebook and seasonal addenda govern it. | Community-event placement/rewards, not RP or TRP by default. [C] MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) |

## 6.2 Ordinary RP and Division advancement

The official RP guide states that winning participants earn **10–50 RP**, depending on performance, with the most valuable player receiving **50**; leaving without participating can yield **0**. Its loss wording says a player may receive **no RP or have 60 RP deducted**, with the most valuable losing-team player receiving no RP. The guide does not provide a complete loss-function equation or a table of every intermediate case. [O, wording qualified] RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points)

Losses can cause demotion. The same guide describes a **three-battle recovery opportunity** after losing enough RP to be demoted: regaining sufficient RP within that window can preserve the division. This is not a documented universal three-loss immunity or protection in every other ladder. [O] RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points)

Higher divisions raise Combat/Victory Point limits and unlock features. The current dedicated Division article also explicitly describes **end-of-season A-Coin/Credit rewards depending on final Season Division and placement, particularly Top 500**. Older community statements that Season Top 500 is purely decorative should not override this newer guide. Exact payout tables should be taken from the live season. [O] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points)

## 6.3 Reworked Tournament: eligibility, ranks and attempts

### Eligibility and daily entry

The current support contract requires:

- Division 4 or higher;
- at least one selected five-mech hangar/preset;
- an available daily attempt. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

Each day grants **eight battle attempts**. An attempt is deducted **at battle start**. The reset occurs daily at the time that the Tournament began, not necessarily at the daily-objective local-midnight reset. At zero attempts, the player waits for reset. No current paid ticket-replenishment system is documented by this guide. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

The official FAQ image embedded in the support article says duration **can vary**, but is **typically three weeks**, starting on Tuesday and ending on Monday, often with a one-day break before the next competition. Treat that as a typical schedule with explicit variation, not a perpetual fixed weekly calendar. The exact current start/end time, mode pool and map rotation belong to the in-game Guidelines. [O, source includes screenshot] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

### Full rank sequence

```text
Novice 3 → Novice 2 → Novice 1
  → Professional 3 → Professional 2 → Professional 1
  → Expert 3 → Expert 2 → Expert 1
  → Master 3 → Master 2 → Master 1
  → Grand Master 3 → Grand Master 2 → Grand Master 1
                                     └─ Legend: Top 500 by TRP
```

**Novice 3** and **Professional 3** are non-drop ranks for the rest of that Tournament once reached. Legend is the elite leaderboard within Grand Master 1, not an additional ordinary three-step tier. Numbered badges display the top players' positions. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

The documentation does not establish every current TRP threshold, placement initialization rule, cross-event reseeding formula, or gain/loss coefficient in text. Historical starting placements and community “one bracket below last event” descriptions are not a safe universal rule. In particular, ordinary RP's 10–50 numbers must not be reused as Tournament TRP amounts. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · TRNCOMM [1](https://www.reddit.com/r/mecharena/comments/1sq8nse/how_tournament_matchmaking_works_and_why_youre/)

### Modes and premades

CPC, 5v5 Deathmatch and FFA can feature in Tournament. Available modes/maps are set per competition. Teams can enter eligible team formats, but teammates cannot have a **rank difference greater than two**. Team Match is unavailable when the current format is FFA. Do not reinterpret the two-rank rule as two full named rank families without checking the client's eligibility comparison. [O; last caution S] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

## 6.4 Tournament rewards and the 2026 correction cycle

The new system separates **competition rank**, **battle-level payout**, and **leaderboard/final standing**. The support guide frames advancement as earning TRP and receiving rewards associated with rank and final leaderboard position. The dated May and June updates further specify battle-level payout policy. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/)

| Stage | Official statement | Correct interpretation |
|---|---|---|
| April launch | Eight-attempt/TRP redesign replaces the previous framework. | Do not teach ticket hoarding or end-of-day heat entry as the current system. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| 5 May adjustment announcement | Early progression was too forgiving, producing “slingshot” advancement into much stronger opposition; harder bots and reduced A-Coin payouts announced. | An official admission of a progression/matching problem, not proof every match is deliberately unwinnable. TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| May reward policy | Team battle victories earn A-Coins; FFA top five qualify; Credits and Fortune Keys remain available regardless of result. | Match-win status and currency eligibility diverge in FFA. TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| 2 June announcement | A-Coin rewards increased across ranks, especially second–fifth places; minor bot changes announced for the next Tournament. | May's reward quantities are not a safe current payout table. The post does not provide a universal long-run income guarantee. TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/) |

All rows are **[O: official statements]**. Phrases such as “several times more A-Coins than the old system” are publisher projections/claims in the May post, not independently measured player earnings. A real income estimate requires active-rank payouts, placement frequencies, attempts used, season length, and event eligibility. TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/)

## 6.5 Skill, progression and competitive validity

Plarium describes divisions/ranks as indicators of skill, but the documented systems also depend on equipment capability, match opportunities, format, performance scoring and bot difficulty. A ranking can be meaningful within its rules without being a gear-independent estimate of mechanical skill. [O inputs; S analytical conclusion] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

**[S-analysis]** Separate at least five concepts:

1. **Execution skill:** aim, movement, timing, information use.
2. **Strategic skill:** mode objectives, map control, lineup and target decisions.
3. **Coordination skill:** repeatable team action and communication.
4. **Account capability:** owned content and upgrade state.
5. **Participation/opportunity:** attempts used, schedule, disconnects, active pool and event rules.

The eight-attempt cap reduces one form of unlimited daily-volume advantage; it does not equalize all accounts, devices, opportunities, or outcomes. The developer explicitly identifies the old 20-player/time-zone problem and the new TRP-versus-hangar mismatch. TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

---

# 7. Matchmaking architecture and bot population

## 7.1 What is actually documented

| Publicly documented factor or behavior | Evidence status | Safe conclusion |
|---|---|---|
| Equipped rarity, rank and level matter to battle experience. | [O] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) | A mixed-strength hangar can encounter optimized opposition; displayed total power is not the complete specification. |
| Selected presets and their potential/highest achievements are considered. | [O] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) | Switching to a weaker visible setup does not guarantee weaker opponents. Exact persistence/weighting is not disclosed. |
| Gear Hub tier does not affect matchmaking. | [O] HUBFAQ [107](https://mecharena-support.plarium.com/hc/en-us/articles/12640339449372-Gear-Hub-FAQ) | Access tier and matching strength are different concepts. |
| Showdown uses a separate equipment-based league context. | [O] HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) | Showdown matching cannot be reconstructed from ordinary RP alone. |
| Tournament can match players with the same TRP despite large SP differences. | [O] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) | TRP progression is consequential; no universal strict SP-equivalence guarantee exists. |
| Bots fill a shortage of available humans with approximately comparable hangar power. | [O, historical staff explanation] SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) | Bots are an intended population mechanism, not merely a tutorial artifact. |
| Partial Team Matches are automatically completed by the system. | [O] TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) | Queueing with one friend does not create an otherwise empty public team. The exact human/bot composition is not guaranteed. |
| Tournament bot difficulty is actively tuned. | [O-announced] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/) | Bot strength and progression pacing can change with live balancing. |
| Showdown can hand control of an AFK ally to a bot. | [O] HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) | Distinguish initial bot fill from temporary takeover of a human slot. |

## 7.2 A bounded reconstruction of the pipeline

![Figure 4. Matchmaking: documented inputs and unknown decision logic](assets/matchmaking.svg)

*Figure 4 — Solid connections are supported at the feature level; the candidate-selection, weighting, widening and team-allocation box is intentionally opaque. The diagram is a conceptual synthesis, not an implementation claim. [S-model] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)*

A reasonable **logical** pipeline is: validate eligibility → select the mode/rank/preset context → find an available participant population → form opposing teams or an FFA roster → supplement with bots where needed → initialize the match. The existence of those broad product functions is supported; their exact execution order, services, parallelization and fallback policy are not. [S-reconstruction grounded in O features] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

Do **not** present the following as known implementation details:

- an Elo, Glicko, TrueSkill, or proprietary numerical MMR formula;
- exact weighting of highest item, mean SP, inventory power, win rate, kills, deaths, or spending;
- a prescribed widening interval or acceptable SP percentage window;
- exact region/server selection, latency threshold, or input-device separation;
- a rule that full premades always meet full premades;
- a minimum human count or fixed bot ratio;
- a guaranteed novice-protection duration or “first N matches are bots” rule;
- a spend-triggered penalty or fixed personal win/loss schedule.

These are **[S-unknown]** unless a future authoritative disclosure or sufficiently strong experiment establishes them. The official statements above are not enough to derive those variables. LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)

## 7.3 Squad Power, Inventory Power and preset potential

**Squad Power** is a summary of an equipped squad's strength; **Inventory Power** and clan power concern a broader collection. Clan support explicitly counts all unlocked mechs and weapons for its inventory-power aggregate, rather than only the active hangar. The clan formula must not be substituted for the public matchmaking formula. [O] SP [2](https://mecharena-support.plarium.com/hc/en-us/articles/12555172477468-Squad-Power) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)

Official July 2026 guidance says that “weak” presets do not automatically yield weaker matches when an account has much stronger gear, referring to selected-preset potential and highest achievements. The wording leaves room for uncertainty about what is remembered and how it is weighted. It does **not** license a precise claim that every owned item is always summed into one hidden match score. [O statement; S boundary] LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets)

**[S-analysis]** Displayed SP is a lossy summary. Even equal totals can conceal different effective range, survivability layers, cooldown availability, mobility, synergy, and deployment depth. Those factors plausibly influence real combat outcomes, but their presence in a gameplay model does not prove the matchmaker explicitly computes all of them. ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 7.4 Bots: roles, behavior and evidence limits

There are at least three documented bot contexts:

1. **PvP population fill** when suitable human availability is insufficient. [O] SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)
2. **Solo PvE enemies** in Onslaught. [O] PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)
3. **Showdown AFK takeover**, allowing a temporarily inactive teammate's mech to be controlled. [O] HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228)

Custom Match adds explicit organizer-controlled **no/equalize/fill** settings. These settings alter slot population; they are not a guarantee that bot difficulty perfectly matches human skill. [O/S-boundary] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match)

Plarium's engineering article documents both Unity NavMesh and an internally developed Astar navigation system. Dynamic world objects can make navigation nodes temporarily unwalkable. That is genuine information about pathfinding, but it does not disclose aim behavior, target-priority logic, reaction delays, hidden accuracy adjustments, or whether every current bot subsystem is unchanged from 2024. [O / S-unknown] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

Friend recommendations intentionally exclude bots, and bots cannot be added as friends in the documented flow. This is useful evidence of a human/bot distinction in social features, not an infallible name-based detector for every combat slot. [O] FRIEND [1](https://mecharena-support.plarium.com/hc/en-us/articles/12726680651036-How-do-I-add-friends)

## 7.5 New players and high-level behavior

The tutorial and progressively unlocked modes limit what novices encounter. Loadout guidance recommends coherent upgrades rather than a single overpowered carry, and the 2026 Tournament correction explicitly addresses advancement beyond hangar readiness. These are verified mechanisms and declared goals relevant to novice experience. [O] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

No reviewed source establishes a complete novice-protection algorithm. At high ranks, Plarium acknowledges that equal TRP can pair a relatively underdeveloped hangar with a much stronger one. Harder bots were proposed to slow premature advancement. That can explain a documented class of difficult matches without proving deliberate targeting, an exact queue policy, or a universal promise of future fairness. [O / S-boundary] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

## 7.6 Community claims versus causal evidence

| Claim heard in the community | Assessment |
|---|---|
| “The system forces everyone to exactly 50% wins.” | [W] Recurring interpretation, contested even within community discussions; no verified target or enforcement formula. TRNCOMM [1](https://www.reddit.com/r/mecharena/comments/1sq8nse/how_tournament_matchmaking_works_and_why_youre/) · BOTDEBATE [3](https://forum.plarium.com/mech-arena/702_game-discussion/1640073_player-discussion-this-is-an-issue/) |
| “Bots always target the human first or intentionally sabotage the human team.” | [W] Player perception and dispute, not a disclosed behavior specification. Observed pressure alone does not identify its cause. BOTDEBATE [3](https://forum.plarium.com/mech-arena/702_game-discussion/1640073_player-discussion-this-is-an-issue/) · BOT2026 [5](https://forum.plarium.com/mech-arena/702_game-discussion/1757208_op-bots/) |
| “Lowering visible SP always gives easy opponents.” | Not a reliable current rule. [O] Official guidance explicitly warns against assuming it; historical manipulation was officially acknowledged. LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| “The game matches paying accounts differently because they spent.” | [S-unverified] Purchase changes gear capability, a documented relevant variable. No reviewed source isolates spending itself as a matching input. CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) |
| “A surprising kill proves hacking.” | Unsupported inference. [O] Timing/synchronization and legitimate mechanics can explain some cases; reports still deserve evidence-based review. SYNC [127](https://mecharena-support.plarium.com/hc/en-us/articles/27620757593756-Cheater-or-Game-Mechanic) · CHEAT [124](https://mecharena-support.plarium.com/hc/en-us/articles/12865857341724-How-to-report-cheaters) |

## 7.7 A responsible validation protocol

**[S-research recommendation]** To investigate a matchmaking hypothesis without reverse-engineering private systems:

1. Define the hypothesis narrowly—for example, an association between one legal preset change and observed opponent power.
2. Record client version, date/time, region/device, mode, RP/TRP/Showdown league, party size, checked presets and full relevant loadout state.
3. Separate human and bot identification into confirmed/uncertain cases rather than relying on nicknames.
4. Record outcomes across a predeclared sample; do not select only dramatic losses.
5. Control for new rank, active map, event Modifiers, daily reset, bots, and party changes.
6. Avoid repeatedly changing several variables at once or deliberately exploiting weaker players.
7. Report associations and confidence limits. Do not label correlation as a recovered algorithm.
8. Replicate after a patch; keep the old result version-scoped.

The methodology is an analyst proposal, not a Plarium-approved experiment or a claim that a public telemetry API exists. It responds directly to the documented version-sensitive inputs and explicit gaps. LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct)


# 8. Clans and group organization

## 8.1 Access, creation and membership

Clans unlock at **League Division 8**. Players can create a clan or browse a list sortable by privacy, power, and open slots. An **Open** clan can be joined directly if it has space; a **Private** clan requires an application approved by the leader. The documented membership limit is **30**. Creation requires a unique name, a **three-to-five-character tag**, and a privacy choice. [O] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)

The creator becomes the initial leader. The current support material explicitly documents leaders and members but does not supply a complete permission matrix for any additional officer/deputy roles. It also does not establish a current universal creation price. “No verified creation cost” must not be rewritten as “creation is free.” [O documented roles; S-unknown details] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)

## 8.2 Clan competition: aggregate statistics, not a clan-war ladder

Two automatically updated global **Top 100** boards are documented:

- **Clan Power:** the sum of members' Inventory Power, explicitly including all unlocked mechs and weapons rather than only their active hangars.
- **Weekly Clan Damage:** members' combined damage over the week, with Custom Matches explicitly excluded. [O] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)

The boards reward different things. Power is an account-collection aggregate; weekly damage reflects activity and damage production. Neither is a demonstrated head-to-head clan MMR or a proof of team tournament strength. Damage accumulation also does not automatically measure objective play or efficient winning. [S-analysis of O formulas] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · MAQC [4](https://maqc.mecharenadev.com/rules)

No verified native clan XP/technology tree, shared bank, resource donations, passive combat-stat bonus, territory system, or clan-war season was established from the reviewed feature documentation. Treat those as **unverified**, not as features borrowed from another Plarium title or a similarly named mech game. CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · TRANSFER [129](https://mecharena-support.plarium.com/hc/en-us/articles/16575925235868-How-to-transfer-resources)

## 8.3 Leadership continuity and dissolution

| Condition | Documented consequence |
|---|---|
| Leader leaves an otherwise populated clan | A new leader is automatically selected. |
| Leader inactive for more than 30 days | Leader is removed and replacement is selected. |
| Replacement selection | Based on Inventory Power and activity in the previous seven days; exact tie-breaking is not published. |
| Last member leaves | Clan disbands. |
| No member enters the game for 30 days | Clan automatically disbands. |
| Manual disband | Leader must become the sole remaining member, then leave. |

**[O] Source for all rules:** CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)

**[S-operational implication]** Clan continuity depends partly on activity and inventory-weighted succession, not solely on a community's intended leadership plan. A serious clan should maintain an external contact directory and agreed contingency process rather than assume its preferred captain will always be selected automatically. Avoid account sharing as a workaround; official rules prohibit unauthorized account access and commercial account trading. CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · BAN [125](https://mecharena-support.plarium.com/hc/en-us/articles/12865625608220-Why-was-I-banned) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct)

## 8.4 Benefits, communication and social significance

Official team play allows inviting friends and clanmates, and grants **10% extra battle XP** when playing with them in eligible Team Matches. This is a teaming benefit, not a documented passive reward merely for wearing a clan tag. Official overview material also notes that objectives can ask players to battle with clanmates. [O] TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/)

Clan chat, recruitment, repeated teammates, and external Discord coordination turn a small in-client organization into a broader social institution. A documented community recruitment example describes external voice channels, practice matches and coordination across player schedules. That is evidence of community practice, not a universal built-in clan feature. [O/C] OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · CLANSOC [3](https://www.reddit.com/r/mecharena/comments/10nk1wv/new_clan_forming_looking_for_members/) · DISCORD [5](https://discord.com/servers/mech-arena-official-542314937624690688)

**[S-analysis]** Clans can provide mentoring, lineup advice, queue partners, scrimmage organization, shared identity and informal reputation. Their strategic contribution is often indirect: a more reliable team can coordinate better than strangers, while an external organizer may accept a team that is not identical to an in-game clan roster. MAQC's registration rules govern its teams; clan membership alone does not substitute for registration. TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · MAQC [4](https://maqc.mecharenadev.com/rules)

## 8.5 Clan administration checklist

**[S-recommendation]** Specify the group's purpose, expected activity, time zones/languages, communication channel, recruitment standard, conduct policy and competitive ambitions. Track active roster capacity, succession risk and registered tournament IDs separately. Do not invent native officer powers, shared currencies or clan-war rewards in recruitment material. Use publicly available profile information and voluntary disclosures; do not collect unnecessary personal data. CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) · MAQC [4](https://maqc.mecharenadev.com/rules)

---

# 9. Events, seasons and live operations

## 9.1 The event system as an objective-and-reward framework

Most timed events offer **objectives → Event Points → milestone rewards**. They appear through the Events interface or event carousel. Availability can require XP thresholds and is time-limited. The concrete objective list, reward pool, duration and eligibility are part of each event instance, not a single universal template. [O] EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

Events should be classified by what they ask players to do:

| Event family | Main behavior or structure | System role |
|---|---|---|
| Battlethon / Deathmatch Mania | Gameplay-related objectives with resource/token rewards. | Activity and mode engagement. |
| Pilot Prizefight | Pilot-related goals, sometimes specific and sometimes broad. | Connects pilot investment/use with its resource ecosystem. |
| Accolade Challenge | Achievement/performance-oriented objectives and rewards, including event tokens. | Encourages specific battle accomplishments. |
| Development Derby | Hangar-development objectives. | Rewards acquisition and upgrade activity. |
| Skin Sprint | Objectives associated with cosmetic rewards. | Collection and customization motivation. |
| Specialization Spree | Use of designated equipment. | Prompts lineup experimentation or specialization. |
| Special-occasion Derby | Objectives unlock day by day, with increasing difficulty/reward value. | Staged engagement over the event window. |
| Playoff | Repeatable-objective milestone stage followed by a competitive leaderboard. | Combines threshold progress with relative competition. |
| Event Crate Rush | Spend specified currency or event tokens for a chance at the published reward pool. | Links event effort and/or purchases with randomized acquisition. |

**[O] Event structures and examples: EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events). The “system role” column is [S-design interpretation].**

Seasonal promotions may also use formats such as **Mega Crate Rush, Endless Roulette, and event metagames**, as documented in the fifth-anniversary program. Their existence does not establish that all roulette-like events have identical odds, token rules, pity systems, or prize removal behavior. Inspect each event's information panel. [O examples / S boundary] ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

## 9.2 Playoff: two-stage event competition

Playoff begins with **repeatable objectives**. Each completion grants Event Points, and an objective can be repeated without a fixed completion count under the described rules. After collecting all rewards in the objectives stage, the player unlocks the leaderboard, where a limited number of prize positions are contested. Unclaimed objective/leaderboard rewards are described as sent to the Inbox after seven days. [O] EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

“Playoff” here is an event label, not proof of a single-elimination bracket or a sequence of head-to-head playoff matches. The score can depend on whatever objective predicates that instance uses. A development objective and a combat objective can produce very different relationships between spending, playing time and rank. [S-analysis grounded in O structure] EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

**[S-recommendation]** Record whether points count before leaderboard access, which actions repeat, what actions are irreversible expenditures, and the exact deadline. Do not presume another player's event bracket assignment or a universal “join late” advantage from old Tournament strategies. The hidden grouping/seeding algorithm for event leaderboards was not established. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/)

## 9.3 Regular objectives and recurring clocks

| System | Documented clock or completion rule | Why it matters |
|---|---|---|
| Daily Objectives | Seven mandatory tasks plus an optional advertisement task; all mandatory tasks yield the main Gold Crate reward. Refresh at local 00:00. | Daily objective completion is not identical to number of matches played. OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) |
| Pilot Daily Objectives | Six offered; complete five for the stated Pilot Mark reward. Refresh at local 00:00. | Provides a pilot-rank resource path with some choice. OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) |
| Weekly Objectives | Seven tasks; completing all grants the stated 200 A-Coins. List refreshes when the main prize is claimed. | “Weekly” is not simply “wait until the next Monday”; optional ad tasks do not count toward the 30-daily-objective task. OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) |
| Gear Hub objectives | Chapters correspond to unlocked Gear Hub tiers. | Their rewards are not Tier Stars and do not themselves unlock the next tier. OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) |
| Basic Implant Crate | Dedicated guide describes two daily opportunities starting at local midnight, with an eight-hour cooldown. | A separate claim clock, not a universal crate-opening timer. IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) |
| Combat Point budget | Partially replenishes every 2.5 hours; division affects cap. | Creates a reward cadence separate from match access. POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) |
| Tournament attempts | Eight daily starts; reset at the competition's start time. | Separate from local-midnight tasks. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| Showdown reward track | Ten reward-bearing daily matches, then additional RP/XP play. | Reward-track exhaustion is not a complete play lockout. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) |
| Login program | Seven-day welcome sequence, then a documented 28-day recurring program; special crate after 20 claimed login rewards. | Additional program variants may exist; storefront notes announced new login programs in 2026. LOGIN [118](https://mecharena-support.plarium.com/hc/en-us/articles/12559453400732-Daily-Login-Program) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) |
| Battle Pass | Runs for its displayed season; eligible XP boosts expire at season end. | Do not assume every named season or event uses this same clock. PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) |
| Inbox | General stored rewards/gifts automatically added after 60 days under the Inbox guide. | Distinguish when an event sends an award to Inbox from when Inbox items are auto-credited. INBOX [131](https://mecharena-support.plarium.com/hc/en-us/articles/16444499048476-Inbox-and-News) |

**[O] All mechanical clock rules are individually sourced. Interpretation column: [S].** For India-based coordination, 06:00 UTC equals 11:30 IST, but ordinary objectives use the documented local-midnight rule rather than that external-tournament time.

## 9.4 Battle Pass architecture

Battle Pass objectives award **Pass Points**, which unlock levels. The **Silver Pass** is free; a purchased **Gold Pass** adds its premium rewards while also retaining the Silver rewards. Current support describes standard and special purchase options, choice rewards, a seasonal Credit Stash and XP boosters. [O] PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass)

Key mechanisms include:

- **Custom Rewards:** choose an option from the offered pool at designated milestones.
- **Seasonal Credit Stash:** duplicates eligible earned Credits during the season under the feature's rules, claimable after season end with Gold Pass access. The broad guide does not specify every source inclusion or cap; consult the current panel.
- **XP boosters:** increase battle XP and its daily limit; multiple boosters can stack.
- **Level Finishers:** complete five Pass levels without completing their objectives.
- **Late purchase:** retroactively unlocks Gold rewards up to the current Pass level.
- **Season end:** ordinary acquired content/resources remain; season-bound XP boosts expire. [O] PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass)

A February 2026 announcement for Season 67 reduced objective difficulty, increased objective points, moved choice rewards earlier and increased reward value. This is a documented response to engagement friction, not proof that every subsequent pass has identical objectives or economic value. [O-announced; S boundary] PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/)

**[S-analysis]** The pass combines predictable progression with a monetized parallel reward track. Choice rewards can reduce the mismatch between a universal track and individual collection needs; retroactive purchase reduces the risk of buying before knowing one's progress. Whether these features improve retention or spending is a research question, not an established causal result. PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/)

## 9.5 Season terminology and Modifiers

At least three uses of “season” coexist:

1. **Battle Pass Season**, explicitly linked to Season Division reset.
2. **Tournament competition/season**, with its own start/end and attempts/ranking.
3. **Themed live-service season**, including lore, content, events and temporary Modifiers. [O] PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/)

**Modifiers** are temporary combat variables—buffs to certain content/classes or environmental effects—that can change damage, reload, HP, cooldowns or other conditions. They unlock after tutorial completion and 5v5 access. Modifier-bearing matches can connect to Event Objectives and rewards. **Mods**, by contrast, are equipped survivability components attached to mechs. Confusing these terms produces erroneous build and economy models. [O] MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods)

The November 2025 announcement proposed seasonal temporary modifiers and slower new-content introduction after a four-stage rebalance. Support now documents the Modifier feature, but that does not validate every promised schedule or prove content-release velocity actually slowed. [O feature/intent / S unmeasured result] REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) · MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers)

## 9.6 Cross-channel live operations

Plarium combines in-game events with website gifts, official social activities, Discord contests, creator communications and desktop/store loyalty. The fifth-anniversary announcement describes a coordinated campaign including events, promo-code hunts, trivia and a community design contest. The September “Plarium Play Event Schedule” post explicitly says its listed token-bearing events launch **across platforms**, despite its title. [O] ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · CAL [2](https://forum.plarium.com/es/mech-arena/854_news/43786_plarium-play-event-schedule--11/) · GIFT [128](https://mecharena-support.plarium.com/hc/en-us/articles/16673365892252-What-are-Plarium-Store-and-Plarium-Store-gifts) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club)

**[S-analysis]** This is a connected live-operations system rather than isolated promotions: community attention can direct players to an event; events award tokens; tokens feed acquisition; acquisition opens build/upgrade decisions; those decisions affect later play. A researcher should preserve channel attribution and dates without assuming an externally published calendar applies identically to every account/cohort. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) · TRIALTEST [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/)

---

# 10. Economy architecture

## 10.1 Closed progression economy, not player trading

Mech Arena's economy centers on account-bound currencies, upgrade materials, equipment ownership and reward tracks. The official **Market** is a Gear Hub acquisition interface, not a player-to-player auction house. Plarium explicitly states that **resources and content cannot be transferred between accounts**. Players may purchase gifts for friends through the official store, but that creates a purchased delivery; it does not transfer the sender's existing balance or inventory. [O] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · TRANSFER [129](https://mecharena-support.plarium.com/hc/en-us/articles/16575925235868-How-to-transfer-resources) · GIFT [128](https://mecharena-support.plarium.com/hc/en-us/articles/16673365892252-What-are-Plarium-Store-and-Plarium-Store-gifts)

Selling, buying or commercially exploiting accounts/game currency/items outside permitted systems can violate the game rules. There is no verified official cash-out or tradable-token economy. Tournament A-Coin prizes are virtual in-game rewards, not cash prize amounts or evidence of a legal exchange rate into money. [O rules; S boundary] BAN [125](https://mecharena-support.plarium.com/hc/en-us/articles/12865625608220-Why-was-I-banned) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) · MAQC [4](https://maqc.mecharenadev.com/rules)

![Figure 5. Economy faucets, inventories, sinks and progression gates](assets/economy.svg)

*Figure 5 — Logical resource flow. “Sink” means a consumption route; XP/RP/Tier Stars are progression measures rather than ordinary spendable balances. [S-model] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass)*

## 10.2 Currency and material system map

| Resource | Principal documented faucets | Principal sinks / uses | Economic role |
|---|---|---|---|
| Credits | Crates, login, objectives, progression, events, achievements, referrals, Tournament, ads, purchases/conversion. | Acquisition of eligible content, gear levels, blueprints and eligible shop/event purchases. | Broad soft-currency budget. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) |
| A-Coins | Purchases, objectives, events, progression, crates/vaults, Tournament, pass, referrals and achievements. | Eligible content, mech/weapon rank-ups, missing upgrade resources, shop refreshes, some crates and conveniences. | Scarcer premium currency also earnable through play. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) |
| Gear-specific Blueprints | Crates, login, shop, events/pass, ads and A-Coin completion of missing requirements. | Level upgrades of the corresponding mech or weapon. | Item-linked progression material rather than a universal currency. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · BLUEPRINT [146](https://mecharena-support.plarium.com/hc/en-us/articles/12554910155676-Why-do-I-need-Blueprints) |
| Pilot XP | Pilot participation and relevant progression/boost mechanisms; A-Coins can cover insufficient XP for level advancement. | Pilot levels. | Separate from account XP. [O] PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) |
| Pilot Marks | Pilot Daily objectives, shop, events, event crates and Battle Pass. | Pilot ranks. | Dedicated pilot advancement bottleneck. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) |
| Implant Parts | Scrapping, relevant rewards/offers, events and pass. | Implant upgrades. | Dedicated customization material; avoid stale removal-for-parts assumptions. [O] IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) |
| Basic / Elite Mod Parts | Events and shop; also listed objective rewards. | Mod acquisition/upgrades, with upgrade stages split between material types. | Separate survivability progression budget. [O] MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) |
| Fortune Keys | Tournament, events, objectives, achievements, shop and Progress Path. | Fortune Vault openings. | Access token for a distinct randomized reward system. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · VAULT [117](https://mecharena-support.plarium.com/hc/en-us/articles/12572771158556-Fortune-Vaults) |
| Event Tokens | Event objectives and shop offers. | The corresponding event crate/interaction. | Event-specific token; expiry/conversion rules require that event's panel. [O] EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) |
| Combat Point booster pool | Shop, Progress Path, events and achievements. | Consumed as additional Combat Points are awarded. | A finite acceleration pool, not indefinite doubled rewards. [O] POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) |

This table describes the economy's categories, not a guaranteed current quantity from every named source. An event can change eligibility, reward availability or the resource mix. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/)

## 10.3 Progress indicators that should not be modeled as money

| Indicator | Accumulation/role | Not equivalent to |
|---|---|---|
| Account XP | Progress Path and feature milestones. | Pilot XP or competitive rank. PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) |
| RP | League and Season Divisions. | TRP or spendable currency. RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) |
| TRP | Tournament rank/leaderboard standing. | Ordinary RP. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| Tier Stars | Cumulative rank-star development within the preceding Gear Hub tier. | A token purchased and then manually spent like Credits. HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) |
| Pass Points | Battle Pass objective completion. | A-Coins or pass purchase entitlement. PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) |
| Achievement / event points | Specific achievement or event progression. | Global account level. ACHIEVE [119](https://mecharena-support.plarium.com/hc/en-us/articles/12575503767708-Mech-Achievements) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) |
| Pilot Points | Pilots' Club loyalty milestones. | Pilot XP, Pilot Marks, or in-battle pilot statistics. CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) |
| Showdown Battle Points | Daily Showdown track. | Ordinary Combat Point-to-Silver-Crate progress. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) |

**[O] All underlying measures are documented. Their treatment as separate ledger types is an [S] data-model recommendation.**

## 10.4 Upgrade dependencies and persistent investment

The core equipment route is **Credits + corresponding Blueprints → level progression**, followed by **A-Coins → rank advancement** for mechs/weapons. Pilots use Pilot XP for levels and Pilot Marks for ranks. Implants use Implant Parts; Mods use their own parts and are capped by host-mech rank. Rarity/grade remains a separate fixed category. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · WEAPON [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · GRADE [110](https://mecharena-support.plarium.com/hc/en-us/articles/12554603916444-Mech-or-Weapon-Grade)

Pilot progression has its own participation rule: the guide states that each pilot paired in the active squad preset receives 800 Pilot XP for a victory or 160 for a draw/defeat. XP stops accumulating at the maximum level of that pilot's current rank until the rank is increased. These are Pilot XP rules, not a replacement for account XP caps, and mode-specific exceptions still need to be respected. [O] PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

**[S-analysis]** The multi-resource design creates bottlenecks: having abundant Credits does not guarantee enough Blueprints; sufficient Pilot XP does not solve a Pilot Mark shortage; spare upgrade materials do not bypass a rank-linked cap. Progression forecasting should therefore track the **limiting requirement**, not convert everything into one fictional universal “power coin.” CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods)

Implants can be removed while retaining their upgrade level under the current guide. Scrapping is irreversible and returns a rarity-dependent base amount plus **30% of invested upgrade parts**. That makes removal and destruction economically different operations. Mods, meanwhile, are **mech-specific and not transferable between mechs** after installation. [O] IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods)

The April 2026 Mod rework lowered costs for non-Legendary hosts, reduced multi-layer shield layer counts while retaining total shield HP in the announcement, tied Mod level to mech rank, and refunded excess invested parts for forced downgrades. These are documented transition policies, **not a general promise of cash refunds for balance changes**. [O] MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/) · MODREWORK [4](https://forum.plarium.com/mech-arena/854_news/43624_-mods-rework-announcement/)

## 10.5 Gear Hub as an access graph

The Gear Hub's Market is a sequence of tiers. Acquiring mechs or weapons earns Tier Stars corresponding to their rank; increasing one of those items' rank contributes one additional star. Pilots, implants and Mods are not another source of Market Tier Stars. Ordinary level upgrades are not the same action. Only stars from the **immediately preceding tier** count toward unlocking the next tier. [O] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HUBOUT [7](https://plarium.com/forum/en/mech-arena/854_news/42409_gear-hub-is-out/)

The Gear Hub FAQ also describes **default weapons** bundled with certain mech acquisitions through supported routes, unless already obtained. These are predefined, their starting rank follows the Market definition, and the player can change the equipped weapon after acquisition. This is an acquisition-bundle rule, not a separate tier currency or unrestricted duplicate grant. [O] HUBFAQ [107](https://mecharena-support.plarium.com/hc/en-us/articles/12640339449372-Gear-Hub-FAQ)

Purchasing or winning an item from a locked tier can permit using/upgrading that item without unlocking the rest of its tier. Tier access, item ownership, item upgrade state and matchmaking exposure are therefore different fields. Gear Hub tier itself is explicitly not a matchmaking factor in the FAQ. [O] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HUBFAQ [107](https://mecharena-support.plarium.com/hc/en-us/articles/12640339449372-Gear-Hub-FAQ)

**Tier-count conflict:** the support Market article still says eight tiers; the community Gear Hub page currently lists ten, while other secondary guides describe nine. The sequential-star mechanism is well documented; the current complete tier count is not treated as conclusively resolved by the stale support number. Verify the live Market before building a complete cost model. [O/C conflict] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HUBWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Gear_Hub)

**[S-analysis]** The access graph encourages breadth or rank investment in the current tier even when a player is mainly interested in later content. An acquisition made for access value can have low immediate combat utility. Conversely, event or paid access to an out-of-tier item can bypass its acquisition path without bypassing the overall tier graph or eliminating future upgrade costs. HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market)

## 10.6 Ordinary play: bounded faucets

The baseline Progress Path guide caps battle-earned XP at **500 per day**, with another **500 available through regular objectives** and additional event/boost exceptions. This is not a promise that one match always awards a fixed XP amount or that account XP can never exceed the baseline via other routes. [O] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · CAP [8](https://mecharena-support.plarium.com/hc/en-us/articles/12642357164700-I-won-a-battle-but-got-no-rewards-Why) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass)

Combat Points award a **Silver Crate per 100 points**; Victory Points award a **Gold Crate per 10 points**. Division affects their caps. First-time division promotion clears the relevant limits, and Combat Point availability partially replenishes every 2.5 hours. Near a full/depleted limit state as described by the UI, A-Coins can clear the Combat Point limit. [O] POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points)

The official booster example is a finite pool: a battle normally earning 60 Combat Points can consume 60 booster points to award 120 total; if only 20 remain in the booster, the award becomes 80. The result screen already includes the bonus. More boosters add to the remaining pool. This is not an unlimited 2× multiplier or a reason to double the displayed result again. [O] POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points)

**[S-analysis]** A valid progression model needs separate counters for base rewards, caps, remaining booster quantity and first-promotion resets. Playing after one route is capped can still have value through another eligible route; Custom and Onslaught exclusions must be represented explicitly. POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught)

## 10.7 Randomized acquisition and expected-value discipline

Crates, Fortune Vaults and Event Crate Rush are distinct mechanisms with different eligibility and reward pools. Official guides direct players to the information icon for item probabilities and quantities. Some rewards are randomized, while other progression milestones or direct shop purchases are specified outcomes. Do not treat all acquisition as one loot-box distribution. [O] CRATE [3](https://mecharena-support.plarium.com/hc/en-us/articles/12572383405084-Crates) · VAULT [117](https://mecharena-support.plarium.com/hc/en-us/articles/12572771158556-Fortune-Vaults) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path)

**[S-model]** For a fixed, disclosed, independent draw with success probability `p`, the probability of at least one desired outcome in `n` draws is `1 − (1 − p)^n`. This is a mathematical illustration only. It is **not** a Mech Arena event formula unless independence and constant `p` are actually verified. Removed prizes, changing odds, limited pools, guarantees, different token costs and duplicate compensation invalidate a naive reuse of that expression. EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · CRATE [3](https://mecharena-support.plarium.com/hc/en-us/articles/12572383405084-Crates)

Likewise, expected utility should be based on the player's needs, not just advertised rarity. An unwanted duplicate, an unusable blueprint surplus and a missing upgrade material do not have equal marginal value. The Blueprints guide explicitly says players can continue receiving blueprints for already-maxed gear; no general universal exchange mechanism is established. The Club explicitly offers resource compensation for duplicate rewarded mechs/weapons, but that should not be generalized to every reward source. [O facts; S economic interpretation] BLUEPRINT [146](https://mecharena-support.plarium.com/hc/en-us/articles/12554910155676-Why-do-I-need-Blueprints) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club)

## 10.8 Monetization channels and economic incentives

Confirmed channels include direct currency/resource/content offers, Battle Pass upgrades and level acceleration, event-token or event-crate acquisition, official web-store offers/gifts, and optional rewarded advertising in documented tasks/faucets. Premium currency is also earnable through gameplay. [O] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · STORE [1](https://store.plarium.com/en/mech-arena/) · GIFT [128](https://mecharena-support.plarium.com/hc/en-us/articles/16673365892252-What-are-Plarium-Store-and-Plarium-Store-gifts) · OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives)

The implant guide explicitly says a special offer algorithm can use a player's development path and preferences. This confirms documented **offer selection/personalization**, not individualized cash pricing, a recovered targeting formula, or a spend-based matchmaking rule. [O with scope boundary] IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants)

The new **Pilots' Club** links account-bound objectives, Premium Store packs and Plarium Play activity to **Pilot Points**. Points can accumulate before membership; website login with the linked Plarium ID is required to track/claim. Milestones lead to content/resources and then repeatable resource rewards. Claimed rewards arrive in Inventory or Inbox, with specified duplicate compensation. [O] CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club)

**[S-analysis]** This rewards cross-channel account linkage and engagement with desktop/direct-store distribution. It should not be described as an in-battle pilot upgrade or as a verified paid subscription: the support guide presents a loyalty membership, not a recurring subscription charge. The specific conversion into spending or retention is not public. CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/)

Payment can accelerate or alter combat-relevant capability. That is more than cosmetic monetization. However, the competitive consequence depends on ownership, upgrade state, matching population, play skill, mode restrictions and normalization. The factual description is **progression and combat-content monetization**, not an unsupported universal verdict that either skill or payment alone determines every result. [O / S synthesis] CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 10.9 Economy balancing and long-run resource dynamics

The May Tournament announcement explicitly states that initial A-Coin payouts were judged unsustainable and adjusted for long-term economic balance. The June follow-up then increased selected payouts. This is direct evidence of active faucet tuning, not evidence of a fixed exchange rate or a static optimal farming routine. [O-announced] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/)

**[S-analysis]** Key economic tensions include:

- generous rewards versus the pace at which upgrade sinks are exhausted;
- gear breadth versus investment concentration;
- new-content acquisition versus the cost of completing a whole competitive hangar;
- reward caps versus player desire for continued useful play;
- surplus materials for maxed content versus shortages elsewhere;
- short event deadlines versus long-term efficient spending;
- combat normalization versus the value of persistent ownership and collection breadth.

An analyst should model **stocks, faucets, sinks, gates and temporal eligibility** separately, then evaluate outcomes by player segment. The official material supports those dimensions; it does not publish total currency issuance, sink consumption, payer shares, or inflation metrics. CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · BLUEPRINT [146](https://mecharena-support.plarium.com/hc/en-us/articles/12554910155676-Why-do-I-need-Blueprints) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown)

## 10.10 Practical forecasting and financial safeguards

**[S-recommendation]** A useful player or simulator budget has fields for current balances, next upgrade requirements, daily/seasonal caps, eligible reward sources, expected placements, and an explicit spending ceiling. Estimate Tournament A-Coin income from the **current payout table × actual eligible placements × attempts used**, not from maximum rewards multiplied by every calendar day. Keep event tokens tied to their event identity and expiry rules. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

Support describes consequences when a Gold Pass refund is processed: rewards can be removed, boosts/stash blocked, resources can become negative if already spent, and that season's pass cannot be purchased again. This is a documented reversal mechanism, not a universal guarantee of refund approval. Purchases and refund policies remain channel-specific. [O] PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass)

---

# 11. Social and community systems

## 11.1 Friends, invitations and teams

Friends can be added through player IDs/recommendations and supported account-social connections. The documented manual friend limit is **100**, while Facebook-connected friends are not subject to that same limit. Bots are excluded from recommendations and cannot be friended. [O] FRIEND [1](https://mecharena-support.plarium.com/hc/en-us/articles/12726680651036-How-do-I-add-friends)

Eligible Team Matches let players invite friends and clanmates. Partial groups are completed automatically, and teaming earns the documented extra battle-XP benefit. Tournament adds its own two-rank-distance restriction, and FFA disables Team Match. Social relationship, party membership, clan membership and tournament eligibility are therefore independent states. [O] TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans)

**[S-analysis]** Social matching reduces the coordination uncertainty of unfamiliar teammates without guaranteeing a favorable opponent. A clan's internal strength can also vary widely; a common tag alone should not be treated as a uniform skill bracket. TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 11.2 Communication, moderation and voice

The game supports text-based social communication, with clan chat described in official overview material. Public community channels provide announcements, discussion, feedback and events. An identified community manager's October 2024 response said native voice chat could not then be implemented and recommended external applications such as Discord. No later universal native-voice launch was verified in this research. [O; historical limitation qualified] OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · VOICE [1](https://forum.plarium.com/mech-arena/702_game-discussion/1712472_voice-chat-system/) · DISCORD [5](https://discord.com/servers/mech-arena-official-542314937624690688)

Automated anti-spam can sanction repeated/similar messages and repeated tagging. Conduct rules also prohibit harassment, offensive content, unauthorized account access, personal-data misuse and unfair third-party software. Cheating reports and communication-abuse reports should follow the appropriate support flows rather than public accusation campaigns. [O] SPAM [148](https://mecharena-support.plarium.com/hc/en-us/articles/12848258278556-Anti-spam-system) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) · CHEAT [124](https://mecharena-support.plarium.com/hc/en-us/articles/12865857341724-How-to-report-cheaters)

**[S-operational recommendation]** Community managers should separate gameplay disagreement, technical complaints and conduct violations. Use IDs and original screenshots privately for moderation; avoid doxxing, demands for login credentials, or treating a player's win rate as sufficient proof of cheating. CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) · CHEAT [124](https://mecharena-support.plarium.com/hc/en-us/articles/12865857341724-How-to-report-cheaters) · SYNC [127](https://mecharena-support.plarium.com/hc/en-us/articles/27620757593756-Cheater-or-Game-Mechanic)

## 11.3 Referral and reactivation flows

The Referral Program connects a shared invitation link with a new player's installation and subsequent division milestones. The referrer and referral can receive rewards; the guide describes additional rewards when three referrals reach Division 1. Eligibility requires first-time installation through the correct invite link and the documented tracking permissions. This is an acquisition/attribution system, not unrestricted rewards for adding existing players as friends. [O] REFERRAL [122](https://mecharena-support.plarium.com/hc/en-us/articles/13609574565788-What-is-the-Referral-Program)

Promo codes can be time-limited, beginner-targeted or designed for experienced returning players. Code-entry attempts are limited and excessive invalid attempts can trigger a cooldown. A code appearing in an old online list is not evidence it remains redeemable on every account. [O] PROMO [130](https://mecharena-support.plarium.com/hc/en-us/articles/15036191425308-What-is-a-Promo-Code)

## 11.4 Spectators, histories and broadcasting

Three distinct things are often confused:

- **A spectator state within an existing battle:** official known-issues documentation uses this term for situations where a player cannot deploy a remaining mech.
- **Battle History:** a recent-results list.
- **A full observer/broadcast feature:** joining friends' matches as an external spectator, free camera, dedicated observer slots or replay export. [O terms; S distinction] KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430) · LOG [123](https://mecharena-support.plarium.com/hc/en-us/articles/12746581379100-What-is-Battle-History) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)

An older staff response said external friend/clan spectating was not planned then because of technical constraints. The reviewed material does not verify a current general broadcast-grade observer suite. Streamed player POVs or community videos do not prove such a suite exists. [O-historical / S-current unknown] SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)

**[S-recommendation]** Organizers should plan a production test before promising live coverage. Verify what a nonplaying observer can actually do, whether a stream affects competitive integrity, whether delay is needed, and how results are captured if no replay is available. Do not remove players from a small lineup merely to improvise observation without a published rule. CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQC [4](https://maqc.mecharenadev.com/rules)

## 11.5 Official and community knowledge channels

The official ecosystem includes Plarium support, staff forum announcements, Discord, social channels, in-game News, and a creator program with historically documented controlled test-server access. The latter is not an open developer build or a public invitation to obtain unreleased accounts. [O] COMMUNITY [142](https://mecharena-support.plarium.com/hc/en-us/articles/13793210473756-Mech-Arena-Official-Communities) · DISCORD [5](https://discord.com/servers/mech-arena-official-542314937624690688) · INBOX [131](https://mecharena-support.plarium.com/hc/en-us/articles/16444499048476-Inbox-and-News) · CREATOR [1](https://forum.plarium.com/mech-arena/702_game-discussion/1444827_developer-build/)

Community wikis and creators can provide tutorials, observations, scrimmages, event coverage and build analysis. Their strengths are practical detail and fast feedback; their risks include outdated pages, mixed-version edits, promotional incentives, selective footage and causal overinterpretation. These are methodological cautions, not blanket claims that community information is unreliable. [S-analysis] BEGINWIKI [3](https://mech-arena-robot-showdown.fandom.com/wiki/Beginner's_Guide) · HUBWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Gear_Hub) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) · MAQC [4](https://maqc.mecharenadev.com/rules)

## 11.6 Retention through relationships

**[S-analysis]** Social systems create durable reasons to return beyond the next item: familiar teammates, shared goals, recognition, obligations to a registered lineup, mentoring and community identity. They can also create coordination burdens, exclusion, harassment risks or dependence on external platforms. A complete product analysis should evaluate both benefits and costs rather than equate more social activity with universally better player welfare. The underlying friend, clan and organizer structures are documented; their net retention impact is not measured here. TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · MAQC [4](https://maqc.mecharenadev.com/rules) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct)

---

# 12. Design philosophy and behavioral analysis

## 12.1 Declared design goals versus observed mechanisms

| Goal or principle | What is officially stated | What can responsibly be inferred |
|---|---|---|
| Accessibility | Launch positioning emphasizes pick-up-and-play mobile combat for different experience levels. [O] REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) | Short matches and adjustable controls reduce some entry friction, but do not eliminate equipment/rules complexity. [S] |
| Readable tactical space | Developer describes landmarks, cover, zoning, range considerations, testing and visual/audio hazard signals. [O] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) | Maps are designed as decision spaces, not merely interchangeable visual backdrops. [S] |
| Content/build diversity | Rebalance announcement aims to elevate underused content and constrain overperformance. [O-intent] REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) | More viable roles could improve choice; actual diversity must be measured after deployment. [S] |
| Competitive pacing | Eight attempts and harder bots were intended to reduce volume exploitation and premature rank advancement. [O-intent] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) | A cap changes the competition's opportunity structure but does not equalize gear or all player circumstances. [S] |
| Economic sustainability | Developer explicitly links Tournament payout changes with long-run economic balance. [O-intent] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) | Rewards and progression are managed as a connected economy, not isolated giveaways. [S] |
| Feedback responsiveness | Pass revisions, trial withdrawal and repeated rebalance announcements cite feedback. [O] PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) | Feedback is part of the public process; this does not establish how representative respondents are or how decisions are weighted. [S] |

## 12.2 What differentiates the system combination

**[S-analysis]** The distinctive package is the combination of:

- mobile-friendly third-person action;
- configurable energy-limited weapon loadouts;
- a multi-mech hangar that supplies mode-dependent tactical depth;
- ability, pilot, implant and defensive layers;
- short objective/kill formats with different life economies;
- persistent resource/rank investment;
- partially normalized Showdown alongside progression-sensitive competition;
- layered live events and cross-platform/social continuity.

None of these is claimed to be unique across the entire game industry. Their combination creates a different experience from a fixed-loadout arena shooter, a pure equipment simulator, or a long-form campaign game. REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)

## 12.3 Accessibility versus competitive depth

Input customization, targeting assistance options, short battles and conspicuous feedback help players start. Tactical depth then arises from map geometry, objective timing, cover, information, angle damage, cooldowns, range coverage and roster management. A low initial control burden can coexist with high strategic and economic complexity. [O features / S synthesis] CONTROL [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575581245340-Controls-and-Battle-Settings) · BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market)

Crossplay broadens participation but also raises ergonomics questions. The sixth rebalance announcement explicitly describes changing a charged-fire interaction because mobile players could not benefit as readily as desktop players. That is direct evidence of a platform-ergonomics concern, not proof that every control difference has been eliminated or that one platform always wins. [O-intent / S boundary] REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/)

## 12.4 Progression power versus competitive comparability

**[S-analysis]** Persistent upgrades create ownership value and long-term goals, while competitive games need results that players can understand as legitimate. Those aims can conflict when a player reaches a rating band before their equipment is ready or when a single aggregate power number hides unfavorable interactions. The May Tournament explanation explicitly documents such a tension. TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

Showdown addresses part of this by normalizing battle ranks/levels, but league restrictions and ownership remain. Custom competitions can add SP brackets and rules, but enforcement then requires accurate registration and evidence. These are different solutions to different fairness problems, not evidence that one universally solves competitive equality. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/)

## 12.5 Behavioral mechanisms: hypotheses, not diagnoses

| Mechanism | Visible system supporting the hypothesis | Potential benefit / risk |
|---|---|---|
| Competence and mastery | Mode learning, rank progression, medals and increasingly coherent builds. DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · MEDAL [2](https://mecharena-support.plarium.com/hc/en-us/articles/12642305648796-Medals) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) | Achievement and learning / frustration if feedback is dominated by opaque mismatches. |
| Autonomy and experimentation | Loadouts, presets, choice rewards and Custom Matches. PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) | Meaningful choice / constrained experimentation when resources are scarce. |
| Relatedness and identity | Friends, clans, tags, community events and teams. CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · DISCORD [5](https://discord.com/servers/mech-arena-official-542314937624690688) | Belonging / social pressure or conflict. |
| Goal-gradient and completion | Milestone tracks, Gear Hub chapters, pass levels. HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) | Clear progress / spending or overplaying to finish a nearly completed track. |
| Variable rewards | Crates, vaults and event draws. CRATE [3](https://mecharena-support.plarium.com/hc/en-us/articles/12572383405084-Crates) · VAULT [117](https://mecharena-support.plarium.com/hc/en-us/articles/12572771158556-Fortune-Vaults) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) | Surprise / misunderstanding probabilities or chasing a desired outcome. |
| Time sensitivity | Daily resets, staged derbies, seasonal endings. OBJECTIVE [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) | Fresh structure / fear of missing an opportunity. |
| Investment attachment | Upgraded gear, collection breadth and sunk resources. CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) | Durable personal goals / reluctance to disengage or anger after changes. |
| Status comparison | Top 500/100, event leaderboards and numbered badges. DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) | Competitive aspiration / unhealthy comparison for some players. |

**All behavioral interpretations in this table are [S].** The existence of the mechanisms is documented; their psychological effect on a particular player, intentional manipulation, addiction prevalence, or causal revenue impact is not established.

## 12.6 Design questions worth measuring

**[S-research agenda]** High-value metrics would include time to first meaningful tactical choice, early hangar coherence, progression bottlenecks, novice retention by mode, match quality by human/bot composition, win probability conditional on capability/rank, event completion by spending segment, reward-per-minute distributions and fairness/trust survey results. Do not imply Plarium publishes or uses this exact metric set. LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

Useful evaluation questions are: Does a new upgrade improve perceived agency after matchmaking changes? Does normalization increase viable ownership breadth? Do capped attempts reduce burnout or increase pressure per match? Does a temporary Modifier create experimentation or simply require additional spending? Are rewards reinforcing objective play or competing personal-score incentives? These are falsifiable product questions, not conclusions.

## 12.7 Implications for responsible live operation

**[S-recommendation]** Communicate changes at the system level: what is changing, who is affected, the intended benefit, how investments are handled, and which results will be monitored. Distinguish a bug fix from a balance change, a cohort test from a global launch, and a reward correction from a universal economy improvement. This approach is particularly important when persistent purchases, hidden matching and visible competitive status interact. The documented pass, Mod, Tournament and Trial transitions provide concrete cases for studying that process. PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/) · MODREWORK [4](https://forum.plarium.com/mech-arena/854_news/43624_-mods-rework-announcement/) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/)


# 13. Technical framework and operational boundaries

## 13.1 Technical evidence inventory

A Plarium engineering article by level designer **Daniil Honcharenko**, published **25 June 2024**, provides a first-person description of work on Mech Arena maps. It is the strongest technical source in this review. Details below are confirmed **for the workflow described in that article**, not guaranteed unchanged components of every September 2026 client. [O] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

| Area | What the developer actually describes | Boundary of the evidence |
|---|---|---|
| Engine | Unity development, Unity components and collaboration with Unity developers. | Exact current engine version and every platform's build configuration are not disclosed. |
| Navigation | Unity/NavMesh and an internally developed Astar wayfinding system for bots. | Do not automatically identify it with a particular commercial A* package. |
| Dynamic geometry | Moving covers, hazards, colliders, animation and synchronized world objects. | Does not reveal complete physics authority or all hit validation. |
| Synchronization scripts | “Movable World Object View” and “Kill Zone View,” including server awareness of moving hazards and deployed objects. | Component names are reported, not a public API or full source-code disclosure. |
| Spawn metadata | Team A/B or FFA applicability; Base, Base Additive and MVP-point types; spawn identifiers. | Does not supply all maps' spawn coordinates or safety algorithms. |
| Internal tools | Level Editor and Level Design Tool; spawn setup, mode selection, minimap generation, range/trajectory visualization and navigation baking. | Internal tools are not necessarily available to players or modders. |
| Level data | JSON Level Preset including scene, mode, spawn points, postprocessing and additional scene/background bundles. | Not proof of the player's inventory database format. |
| Production/build workflow | Source branches accessed through Sourcetree and automated Jenkins builds/server-data updates. | Not a complete CI/CD, repository-host or backend-language inventory. |
| Performance/testing | Baked lighting, occlusion culling, collider inspection, recordings, heatmaps and multiple playtests at different progression states. | The described process is not a published frame-rate guarantee or coverage of all QA. |

**[O] All facts in the middle column derive from ENGINE; right-column limitations are [S-methodological boundaries].** ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

## 13.2 Client, server and persistent account: a defensible logical split

The game is always online; support explicitly describes client/server synchronization and the effect of connection quality. Settings define ping as the round trip from device to server and back. Plarium ID enables persistent cross-platform progress. These support a client-connected, account-persistent service, but not a complete physical architecture. [O] OFFLINE [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline) · SYNC [127](https://mecharena-support.plarium.com/hc/en-us/articles/27620757593756-Cheater-or-Game-Mechanic) · SETTING [132](https://mecharena-support.plarium.com/hc/en-us/articles/12746754445724-Game-Settings) · ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · ID [134](https://mecharena-support.plarium.com/hc/en-us/articles/26835074933532-What-is-Plarium-ID)

![Figure 6. Technical architecture: verified components and unspecified services](assets/technical.svg)

*Figure 6 — Logical boundaries only. Unity/map tooling and client–server communication are documented. Logical account, matchmaking, economy and live-operation responsibilities do not imply separate microservices or a named cloud. [O/S] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events)*

The engineering source says map geometry is placed locally on the device and describes notifying/synchronizing server state for moving objects. It also explains fixing cases where dangerous colliders were not understood by the server after a player left. That is evidence of meaningful server-side world-state handling. It is **not** sufficient to assert fully authoritative simulation of every action, client-authoritative damage, deterministic lockstep, rollback, or a particular lag-compensation algorithm. [O / S-unknown] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

A product-level reconstruction may logically separate account persistence, queue formation, match simulation, progression calculation, commerce validation and live configuration. It cannot infer whether these functions are monolithic or distributed, which databases they use, or how many servers exist. [S-model]

## 13.3 Platform requirements and performance

| Platform | Current support minimum | Recommended guidance / caveat |
|---|---|---|
| iOS | iOS 15 or later. | Support recommends roughly iPhone 11 Pro / iPad Air 2022 or newer capability. |
| Android | Android 5.0+ and at least 2 GB RAM in the support guide. | Support cites a modern flagship-equivalent device and notes older high-end devices with 8 GB+ can still perform well. Store eligibility is decisive for a particular device/build. |
| Desktop | Windows 10 21H1+ or macOS Monterey 12+; Core i3/Athlon class; listed integrated/vendor graphics or GTX 650; 5 GB RAM. | Recommended Core i5/Ryzen 5 class, GTX 1050 Ti or listed vendor equivalents, 8 GB RAM. |
| Desktop storage / graphics API | Product page lists 6 GB minimum storage, 8 GB recommended and DirectX 11. | DirectX listing is a Windows requirement; do not interpret it as a native macOS API requirement. |

**[O] Requirements from current support/product material; last-column interpretive cautions [S].** SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) · PRODUCT [5](https://plarium.com/en/game/mech-arena/)

Older PC pages mentioning Windows 7 are superseded. The May 2026 iOS notice says iOS 14 and earlier will not receive future updates, although the store may offer a last-compatible version. This reconciles part of the conflict with storefront metadata still showing a lower iOS minimum: installation eligibility is not necessarily current live-service compatibility. [O] DESK [7](https://mecharena.game/mech-arena-pc-mac/) · IOSNEW [138](https://forum.plarium.com/mech-arena/854_news/43692_----important-info-for-ios-players/) · SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228)

The controls guide offers a test battle for trying settings; that is not evidence of an unrestricted content sandbox. [O / S-boundary] CONTROL [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575581245340-Controls-and-Battle-Settings) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/)

The settings guide exposes graphics/shadow controls, camera sensitivity, FPS/ping indicators and 30/60 FPS options. This is not a statement of server tick rate, nor proof that every future/desktop configuration is limited to precisely those settings. Performance can also be affected by thermal throttling, battery-saving modes and background workloads. [O] SETTING [132](https://mecharena-support.plarium.com/hc/en-us/articles/12746754445724-Game-Settings) · SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide)

## 13.4 Crossplay, identity and synchronization

Accounts can be connected to Plarium ID and supported platform/social identities. For moving between Android, iOS and Plarium Play, support specifically recommends **Plarium ID**. Desktop instructions emphasize linking the existing mobile profile before beginning under a different/new account. One should not assume unrelated new accounts can later be merged. [O] ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · PCSYNC [135](https://mecharena-support.plarium.com/hc/en-us/articles/12759575300636-How-to-continue-my-progress-on-Plarium-Play) · PC [2](https://forum.plarium.com/en/mech-arena/854_news/31666_mech-arena-is-live-on-plarium-play/)

Official desktop guidance also states that the same account should not be played simultaneously on two devices. Cross-progression means continuing the same account across platforms, not creating two independent concurrent agents that share an inventory. [O] DESK [7](https://mecharena.game/mech-arena-pc-mac/)

**[S-operational recommendation]** Before switching devices: record the player ID, confirm the linked email/identity, use the supported sign-in flow, and verify the intended profile before making purchases or starting a new progression path. A public player ID is useful for support and registration; account passwords and store verification documents are not. ID [134](https://mecharena-support.plarium.com/hc/en-us/articles/26835074933532-What-is-Plarium-ID) · ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · SECURITY [149](https://mecharena-support.plarium.com/hc/en-us/articles/12831378454684-Security-Policy-How-to-Keep-your-Account-Safe)

The 2026 age-verification FAQs say Apple/Google handle verification and share an age-range signal (and, where relevant, parental approval status). The game does not receive the underlying ID documents, verification payment details or date of birth through that flow. Do not turn that narrowly described process into a claim about all personal data collected by every part of the service. [O, scope-qualified] AGEAPPLE [139](https://mecharena-support.plarium.com/hc/en-us/articles/28973369510172-Age-Verification-FAQ) · AGEPLAY [140](https://mecharena-support.plarium.com/hc/en-us/articles/28974098136220-Age-Verification-FAQ)

## 13.5 Network behavior and troubleshooting

No offline mode is documented, including for the single-player PvE offering. Storefronts advertise 4G/LTE play; the support article recommends stable Wi-Fi and says mobile internet is not sufficient to guarantee an error-free experience. The defensible interpretation is that cellular play is supported/promoted but connection quality matters—not that “no Wi-Fi” means no internet, or that cellular transport is categorically blocked. [O] OFFLINE [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline) · PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US)

Latency and synchronization can make a player perceive damage after entering cover or see actions at slightly different times. The official explanation supports a network-timing interpretation for some incidents; it does not prove every suspicious event is lag, reveal interpolation windows, or justify ignoring actual cheat evidence. [O / S boundary] SYNC [127](https://mecharena-support.plarium.com/hc/en-us/articles/27620757593756-Cheater-or-Game-Mechanic)

**[S-runbook]** Distinguish low rendering FPS from high network ping. Record both when possible, then capture device/OS, client version, connection type, mode/map, timestamp, error and reproduction steps. A UI resource delay, an incorrect displayed preset power and a simulation problem may require different investigations. The known-issues guide even notes that a lobby badge can display the highest available preset power rather than the currently selected one. SETTING [132](https://mecharena-support.plarium.com/hc/en-us/articles/12746754445724-Game-Settings) · BUG [141](https://mecharena-support.plarium.com/hc/en-us/articles/13793527485852-How-to-create-a-good-bug-report) · KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430)

Official support can be reached through the in-game profile/Connection support flow, the help center, or **arena.support@plarium.com**. Include the player ID, relevant original screenshots and requested device/error details; never include a password. [O] SUPPORT [3](https://mecharena-support.plarium.com/hc/en-us/articles/13793049362332-How-to-contact-Support) · BUG [141](https://mecharena-support.plarium.com/hc/en-us/articles/13793527485852-How-to-create-a-good-bug-report) · SECURITY [149](https://mecharena-support.plarium.com/hc/en-us/articles/12831378454684-Security-Policy-How-to-Keep-your-Account-Safe)

## 13.6 Updates, configuration and experiments

Storefront version histories and forum announcements document repeated client updates, while release notes often say a build “lays the groundwork” for subsequently activated content/events. Current support can document features after that announcement. Do not assume every feature listed in a release note activates simultaneously in every account, platform or region. [O statements / S inference boundary] APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) · V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · TRIALTEST [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/) · CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club)

Cohort-restricted Content Trial is direct evidence that not every player sees the same feature state. The engineering account also documents updating level data on a test server and assembling test builds. Together these justify tracking **build version, configuration date, feature cohort and event instance** separately in research. They do not reveal a complete remote-configuration service or rollout system. [O / S model] TRIALTEST [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

## 13.7 Anti-cheat and account security

Current support confirms an **automatic anti-cheat system** and a manual **Report Cheater** button in player profiles. It describes an initial 24-hour ban, escalating durations for subsequent violations and possible permanent suspension. The reporter may receive confirmation if a reported player is banned. These are documented processes, not evidence of perfect detection or a known false-positive rate. [O] CHEAT [124](https://mecharena-support.plarium.com/hc/en-us/articles/12865857341724-How-to-report-cheaters)

The 2022 desktop launch explicitly disclosed **Denuvo** installation for cheat detection/prevention. It is valid historical evidence. Without a current vendor disclosure or direct audited client inspection, this dossier does not assert the exact 2026 Denuvo integration, startup behavior, kernel component, replacement status, or deployment on every platform. [O-historical / S-unknown] PC [2](https://forum.plarium.com/en/mech-arena/854_news/31666_mech-arena-is-live-on-plarium-play/)

Rules prohibit unfair third-party hacks/mods/scripts, account trading and other misconduct. Equipment “Mods” are legitimate in-game components; external “modded clients” are not the same concept. Support also warns that no Plarium employee will ask for an account password and highlights fake free-currency/login offers as an account-compromise risk. [O] MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) · BAN [125](https://mecharena-support.plarium.com/hc/en-us/articles/12865625608220-Why-was-I-banned) · SECURITY [149](https://mecharena-support.plarium.com/hc/en-us/articles/12831378454684-Security-Policy-How-to-Keep-your-Account-Safe)

## 13.8 Publicly unknown implementation details

The following remain **[S-unknown / not established]**:

- production cloud/hosting provider and regional datacenter map;
- match-server process model, sharding, capacity, autoscaling and failover;
- authoritative responsibility for every movement, collision, ability, hit and reward;
- current server/client language split and complete backend frameworks;
- transport/protocol, tick rate, snapshot rate, interpolation, rollback or lag compensation;
- database types, schemas, analytics pipeline and fraud-detection models;
- anti-cheat signatures, thresholds, operational coverage or effectiveness rates;
- queue-time service levels and exact human-population statistics;
- a supported public gameplay/statistics API, official replay export or community mod SDK;
- comprehensive native spectator/observer capabilities.

Unity does not imply Photon, PlayFab, Firebase, AWS or a particular C# server. A public website technology or help-center API does not reveal the game's backend. This report's JSON knowledge map is a research artifact, not an extracted Plarium schema or supported game integration. ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament)

---

# 14. Tournament ecosystem and organizer operations

## 14.1 Four distinct competitive layers

| Layer | Operator and competitive unit | What it is not |
|---|---|---|
| In-game Tournament | Plarium; daily-limited battles producing individual TRP/ranks/rewards. [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) | A registered team knockout bracket. |
| Officially promoted community competition | Community organizers, with official promotion/support in documented cases such as MAQC. [O/C] MAQCOFF [3](https://x.com/MechArenaMobile/status/2058872024777252880) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · MAQC [4](https://maqc.mecharenadev.com/rules) | Automatically a franchised professional league or cash-prize esport. |
| Independent clan/community event | Organizers use Custom Matches and their own published rules. [C/O capability] CLANSOC [3](https://www.reddit.com/r/mecharena/comments/10nk1wv/new_clan_forming_looking_for_members/) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) | A native clan-war system merely because clans participate. |
| Practice/scrimmage | Players arrange lobbies for preparation and learning. [O capability / C practice] CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · CLANSOC [3](https://www.reddit.com/r/mecharena/comments/10nk1wv/new_clan_forming_looking_for_members/) | An automatically ranked or reward-bearing game mode. |

Official promotion of one event does not certify every similarly named Discord server, prize promise or rulebook. Verify the actual organizer, current rules and official link chain before sharing accounts, paying an entry fee or advertising rewards. [S-recommendation] MAQCOFF [3](https://x.com/MechArenaMobile/status/2058872024777252880) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · SECURITY [149](https://mecharena-support.plarium.com/hc/en-us/articles/12831378454684-Security-Policy-How-to-Keep-your-Account-Safe)

## 14.2 MAQC: current Season 7 snapshot

**Mech Arena Quarterly Clash (MAQC)** is the central source-backed organized-competition example in this research. Its live site identifies Season 7 as a fifth-anniversary edition. At the **7 September 2026** cut-off, the organizer site says registration is closed and Week 4 of a **six-week** competition is beginning. [C-organizer primary] MAQCLIVE [144](https://maqc.mecharenadev.com/)

| Rule or property | Live Season 7 specification |
|---|---|
| Series format | Weekly **best-of-three** matches; first team to two match wins takes the series. |
| Registered roster | **Three to five players**; no substitutes. |
| Identity | Only registered players and IDs permitted; one team per player. |
| Lobby bots | **Equalize**. This is not Season 6's “Fill or Equalize” choice. |
| Maps | Organizer-designated map(s); Week 4 requires every match of the series on its named map. |
| Calendar | Weekly result deadline Sunday 06:00 UTC; scheduling assistance must be requested before the relevant Friday cutoff. |
| Power registration | Absolute maximum achievable SP using a standard fully equipped five-mech hangar, including pilots, implants and Mods; not a reduced/preferred setup. |
| Reward pool | **5,000,000 A-Coins** on the live site/rulebook. |
| Reward model | More wins and higher SP brackets increase rewards; no wins means no participation/consolation reward under the stated Season 7 rules. |
| Authority | Moderators' final decisions govern disputes; the rulebook states they are final and non-appealable. |

**All rules in this table: [C], primary organizer rulebook/current notices.** MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/)

The live Week 4 announcement reports **1,319 teams and 4,893 pilots**. These are organizer-reported participation figures, not an independently audited game-wide active-player count. MAQCLIVE [144](https://maqc.mecharenadev.com/)

### Why cached material is unsafe

Search results for the same rules URL still describe **Season 6**, whose announcement used weekly single matches, eight matchmaking brackets and a 1.2-million-A-Coin plus Mod-Part pool. The July 2026 Plarium anniversary press release announced **2 million A-Coins** and an earlier registration window. The current organizer page instead lists **5 million**, Bo3 and later schedules. Preserve the older statements as history; use the live current-season rules for operations. [O/C conflict] MAQC6 [1](https://www.reddit.com/r/mecharena/comments/1tml0fs/mech_arena_quarterly_clash_season_6_registrations/) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/)

Even the live homepage and base rulebook differ in the displayed historical initial-registration cutoff time. Registration is now closed, but a retrospective audit should request the authoritative dated addendum rather than fabricate one reconciled deadline. MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/)

## 14.3 Weekly addenda and operational precedence

The current notices refine the base rulebook:

- Match scheduling must be agreed by both captains in the assigned battle post.
- Rescheduling needs at least **six hours' notice**.
- For a no-show, wait **ten minutes** and contact an active moderator with evidence.
- Unresponsive opponents after **72 hours** should be escalated through the specified support/ticket process before the Friday deadline.
- Current announcements require communication in the assigned battle post; DMs/external servers are not accepted as dispute evidence.
- Results require **unedited screenshots** in the correct location before the weekly cutoff.
- A **12-hour weekly SP-update window** allows increases to registered SP; players cannot lower it.
- Previously public tolerance figures now have **undisclosed variance**; do not treat old percentages as guaranteed legal boundaries. [C] MAQCLIVE [144](https://maqc.mecharenadev.com/)

For Week 4 in this snapshot, the published scheduling cutoff is **Friday 11 September, 06:00 UTC**, and the match/result cutoff is **Sunday 13 September, 06:00 UTC**—both **11:30 IST**. This is a dated operational example, not a perpetual timetable for all competitions. MAQCLIVE [144](https://maqc.mecharenadev.com/)

**[S-recommendation]** Maintain a hierarchy: current weekly addendum → current-season rulebook → older announcement. Save the actual text/date used for a match. Never apply an obsolete SP tolerance to justify manipulation, or assume the publisher's public matchmaker uses the organizer's SP-bracket logic. MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience)

## 14.4 End-to-end organizer workflow

The following is a **proposed operating framework [S]**, grounded in Custom Match capabilities and documented MAQC requirements. It is not an assertion that every organizer already follows it. CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQC [4](https://maqc.mecharenadev.com/rules)

| Phase | Decisions and artifacts to prepare |
|---|---|
| Competition charter | Organizer identity, ruleset scope, eligibility, prize funding/fulfilment, public schedule, conduct and data-minimization policy. |
| Format design | Team size, single-match/Bo3/other series, map pool, progression or normalization restrictions, bot setting, side selection, ties and disconnect policy. |
| Registration | Unique player IDs, captain contact, roster lock, allowed substitutions, maximum-power disclosure if required, agreement to rules. |
| Seeding/pairing | Publish whether pairing is bracketed, round-robin, elimination or another format; do not rely on undocumented in-game matchmaking for an external event. |
| Technical rehearsal | Client version, all required unlocks, map availability, legal bot settings, connectivity, result screenshots and any spectator/streaming workflow. |
| Match operations | Confirm participants and IDs, setup, schedule and declared loadouts; capture proof before start. |
| Result ingestion | Original screenshots, match/series identifiers, agreed score, correct channel and submission time. |
| Disputes | Consistent evidence requirements, escalation deadlines, documented moderator ruling and sanctions. |
| Reward delivery | Verified recipient IDs, published eligibility, duplicate/error handling and confirmation of successful fulfilment. |
| Postmortem | No-show rate, dispute rate, power violations, scheduling burden, technical failures and player feedback. |

A **match**, a **round within that match**, a **series**, a **weekly pairing**, a **power bracket**, and a **season** must have separate identifiers. This avoids confusing “won two rounds of Deathmatch” with “won two matches of a Bo3 series.” [S-data-model recommendation] DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · MAQC [4](https://maqc.mecharenadev.com/rules)

## 14.5 Minimum match-day checklist

**[S-recommendation; current MAQC specifics must be taken from its own rules]**

- Verify all participants and player IDs against the locked roster.
- Confirm correct client/rules version, mode, map and bot setting.
- Record equipment restrictions and relevant active Modifiers.
- Check the current SP declaration and bracket policy where used.
- Confirm start time, no-show procedure and result deadline in UTC and local time.
- Capture setup evidence before launch and originals after each match.
- Record which team won the series; do not rely on a single cropped MVP screen.
- Escalate crashes/disconnections according to the published policy; do not assume an automatic restart.
- Submit results and disputes in the right channel before the deadline.
- Protect account credentials and minimize collection of personal information.

These actions address limitations present in the documented systems: no generic Custom rewards, constrained host options, externally administered series and evidence-dependent disputes. CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) · SECURITY [149](https://mecharena-support.plarium.com/hc/en-us/articles/12831378454684-Security-Policy-How-to-Keep-your-Account-Safe)

## 14.6 Esports potential and constraints

**[S-analysis]** Positive foundations include short bounded matches, tactical team play, a cross-platform player pool, private lobbies, recognizable modes, official community promotion and demonstrated multiweek organized participation. Constraints include unequal equipment investment, opaque public matching, bot use in some formats, restricted observer evidence, mobile/desktop ergonomics and a significant administration burden. REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQCOFF [3](https://x.com/MechArenaMobile/status/2058872024777252880) · MAQCLIVE [144](https://maqc.mecharenadev.com/) · REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/)

A credible growth path would prioritize stable versioned competition rules, transparent eligibility and prize operations, stronger observation/result tooling, repeatable fair-format design and manageable schedules. The reviewed sources do not establish a franchise model, professional salaries, major LAN circuit, game-wide cash prize market, or broadcast SDK. Community activity should neither be dismissed as nonexistent nor inflated into an unverified mature professional esport.

---

# 15. Meta formation and balance dynamics

## 15.1 What “the meta” means here

**[S-analysis]** The meta is the set of strategies, roles, investment patterns and team compositions players tend to adopt because they appear effective under a particular ruleset and population. It is not a single permanent item ranking.

Mech Arena has multiple relevant metas:

- territorial control and reinforcement management in CPC;
- round trades and lead preservation in Deathmatch;
- kill conversion, self-sustain and cycling in FFA;
- sequential picks and league-specific restrictions in Showdown;
- gated encounter clearing in Onslaught;
- coordinated, rule-constrained play in external competition;
- account-efficient progression under resource scarcity. CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · MAQC [4](https://maqc.mecharenadev.com/rules) · CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies)

This section intentionally discusses **no individual mech or weapon**. The unit of analysis is the system interaction, not an equipment tier list.

## 15.2 Meta formation as a feedback loop

```text
rules + map geometry + owned/upgraded options + opponent population
  → experimentation and repeated play
  → observed successful roles/interactions
  → guides, videos, imitation and squad practice
  → changing pick rates and counterplay
  → developer analysis / feedback / updates
  → a new rules-and-incentive context
```

**[S-model]** The loop is grounded in documented map testing, official loadout advice, community knowledge channels and developer balance announcements. No public pick-rate or causal win-rate dataset was obtained to quantify its stages. ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · COMMUNITY [142](https://mecharena-support.plarium.com/hc/en-us/articles/13793210473756-Mech-Arena-Official-Communities) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/)

## 15.3 Structural drivers of strategic value

| Driver | Why it can change strategy |
|---|---|
| Map size, verticality, cover and hazards | Alters useful engagement ranges, rotation time, safe positions and exposure. [O design / S implication] ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) |
| Territorial versus kill objectives | Changes the relative value of mobility, survival, pressure and finishing kills. [O rules / S implication] CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) · DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| Finite lives versus reusable cycles | Changes whether preserving a life or accelerating access to the next option is useful. [O/C rules / S implication] FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · MODESWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) |
| Layered defenses and damage delivery | Changes effective survivability and the value of timing, repeated hits and defense interaction. [O mechanics / S implication] MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) |
| Cooldowns, disable effects and coordination | Changes usable action windows and the ability to combine pressure with teammates. [O mechanics / S implication] BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) |
| Ownership and upgrade ceilings | Defines the feasible strategy set, not just an ideal unconstrained theoretical lineup. [O/S] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) |
| Temporary Modifiers | Temporarily changes relative value and can encourage experimentation. [O-intent/S effect] MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers) |
| Ranking and reward rules | Can make economic success differ from match-winning success, especially FFA top-five payouts. [O/S] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| Population and bot adjustments | Changes the opposition a strategy is optimized against. [O/S] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) |
| External event restrictions | Produces a separate competition meta within roster/SP/map rules. [C/S] MAQC [4](https://maqc.mecharenadev.com/rules) |

## 15.4 Stated balance philosophy

The November 2025 announcement promised a four-stage November–February rebalance with approximately **four buffs per nerf**, iterative changes and **two weeks' advance notice**. It emphasized improving underused content and broadening choices. That ratio and schedule are a statement about that planned program, not a permanent guarantee governing all future updates. [O-intent] REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/)

Later waves show continuation of the process. The sixth-wave announcement, planned for 4 September 2026, includes both power tuning and control-usability changes; the latter explicitly addresses mobile-versus-desktop handling. The Mod rework likewise changes availability, upgrade ceilings and shield structure rather than only a single damage number. [O-announced/deployed Mod change] REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/)

**[S-analysis]** Rebalancing can act through several levers: direct power, ease of execution, counterplay windows, defense interactions, progression access, upgrade cost and temporary seasonal context. A patch's strategic effect therefore cannot be predicted merely by counting how many entries are labeled buff or nerf. REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) · REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/)

## 15.5 Investment, feedback and community response

Official communications acknowledge frustration about Tournament matchmaking, overly demanding pass objectives and limited trial usefulness. Those are documented developer responses to feedback. Community discussions also show disagreement about bot strength, fairness and the value of invested resources after changes. The existence of such reactions is not a representative opinion poll. [O/C/W, scope-qualified] TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · PASS67 [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · MODREWORK [4](https://forum.plarium.com/mech-arena/854_news/43624_-mods-rework-announcement/) · BOTDEBATE [3](https://forum.plarium.com/mech-arena/702_game-discussion/1640073_player-discussion-this-is-an-issue/)

**[S-analysis]** Persistent investment makes balance changes emotionally and economically consequential. A change can improve overall counterplay while reducing the utility of one player's prior purchases. Conversely, protecting every old advantage indefinitely can undermine newer-player access and long-run diversity. A serious analysis should compare systemic outcomes and investment treatment rather than equate all nerfs with malice or every stated buff program with proven balance improvement. MODREWORK [4](https://forum.plarium.com/mech-arena/854_news/43624_-mods-rework-announcement/) · REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/)

## 15.6 A patch-adaptation workflow

**[S-recommendation]**

1. Record the changed rule, deployment date and affected **system category**.
2. Separate permanent balance changes from temporary Modifiers.
3. Check whether the change alters access, cost, execution, survivability or competitive rewards.
4. Test against comparable conditions, not one favorable highlight.
5. Reassess each relevant mode separately.
6. Consider whole-hangar depth and current ownership rather than only theoretical maximum capability.
7. Recheck external tournament restrictions and registered maximum power.
8. Revise guides with a version/date and preserve older findings as history.

This workflow is intended for players, analysts and wiki maintainers. It is not a claim that public match data is sufficient to isolate every causal effect. REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) · MODIFIER [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) · MAQCLIVE [144](https://maqc.mecharenadev.com/)

---

# 16. Structured ecosystem map and knowledge model

## 16.1 Complete systems taxonomy

The following is a **conceptual organization [S]** of the documented product. It deliberately avoids claiming that Plarium uses these module names internally.

```text
MECH ARENA ECOSYSTEM
├─ Access and identity
│  ├─ Android / iOS / desktop distribution
│  ├─ Plarium ID and supported platform connections
│  ├─ cross-device progress; age/store eligibility
│  └─ settings, support, account security and moderation
├─ Persistent player account
│  ├─ account XP → Progress Path → Endless Path
│  ├─ RP → League Divisions → Season Divisions → Top 500
│  ├─ inventory ownership and resource balances
│  ├─ profile, achievements, medals and recent battle history
│  └─ Inbox, News, referrals and loyalty progress
├─ Collection and configuration
│  ├─ Gear Hub Market → Tier Stars → sequential access
│  ├─ mech ranks/levels and energy capacity
│  ├─ weapon compatibility and ranks/levels
│  ├─ pilots → Pilot XP/Marks → ranks/levels
│  ├─ implants → slots, effective-level cap, parts and scrapping
│  ├─ mech-specific Mods → specialized slots and parts
│  ├─ cosmetics / identity expression
│  └─ saved presets → checked/eligible configurations
├─ Combat and sessions
│  ├─ controls, aiming, movement, abilities, defenses and information
│  ├─ maps, objectives, spawns, hazards and bot navigation
│  ├─ ordinary Quick / Team Match
│  ├─ CPC → Influence / territorial and elimination victory
│  ├─ Deathmatch → kill-scoring rounds
│  ├─ FFA → placements / leader / healing / five-mech recycling
│  ├─ Showdown → equipment leagues / normalization / sequential picks
│  ├─ Onslaught and event trial encounters
│  └─ Custom Match → host setup / Match ID / bot options
├─ Competition
│  ├─ ordinary RP divisions and seasonal standing
│  ├─ Tournament → attempts / TRP / ranks / Legend / rewards
│  ├─ Showdown daily reward track
│  ├─ event-specific leaderboards
│  ├─ clan power and damage Top 100
│  └─ community competition → roster / bracket / series / adjudication
├─ Economy and live operations
│  ├─ Credits, A-Coins and upgrade materials
│  ├─ Combat/Victory Points → crates; reward caps and boosters
│  ├─ regular / pilot / weekly / Gear Hub objectives
│  ├─ login cycles, achievements and first clears
│  ├─ timed events, derbies, Playoffs, Crate Rush and tokens
│  ├─ Battle Pass → free/premium tracks / choice / stash / boosts
│  ├─ web store, gifts, promotions, ads and Pilots' Club
│  └─ seasons, Modifiers, balance changes and feature experiments
└─ Social and operational ecosystem
   ├─ friends / invitations / premades
   ├─ clans / recruitment / succession / chat
   ├─ official support, forum, Discord, social channels and creators
   ├─ community wikis, tests, guides and streams
   ├─ tournament organizers / moderators / captains / players
   └─ feedback → investigation → updates → new play context
```

**Source basis:** official system guides, engineering account and current organizer material. ACCOUNT [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) · MAQC [4](https://maqc.mecharenadev.com/rules)

![Figure 7. Connections across progression, competition and social play](assets/ecosystem.svg)

*Figure 7 — A condensed dependency view of the full taxonomy above. Functional relationships are source-backed; the visual organization is an analyst model, not a backend service layout. [S-model] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · MAQC [4](https://maqc.mecharenadev.com/rules)*

## 16.2 Dependency matrix

| From | Relationship | To | Evidence / boundary |
|---|---|---|---|
| Account XP | Unlocks milestones | Progress Path features, then Endless Path | [O] PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) |
| RP standing | Unlocks feature access and later seasonal competition | Divisions, modes and point caps | [O] DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) |
| Item acquisition/rank increase in the preceding tier | Accumulates | Gear Hub Tier Stars | [O] HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) |
| Gear Hub tier access | Allows normal acquisition opportunity | Tier content | [O]; not automatic ownership. HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) |
| Out-of-tier event/paid reward | Grants ownership without unlocking whole tier | Individual usable content | [O] HUBFAQ [107](https://mecharena-support.plarium.com/hc/en-us/articles/12640339449372-Gear-Hub-FAQ) |
| Equipped weapons | Consume capacity budget | Mech energy capacity | [O] MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · WEAPON [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons) |
| Pilot rank | Caps effective implant level | Equipped implant effect | [O] PILOT [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) |
| Mech rank | Gates/caps | Mod access and upgrade level | [O] MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) |
| Checked presets | Participate in | Matchmaking/pre-match selection | [O]; exact weighting unknown. PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) |
| Tournament mode + five-mech eligibility + attempts | Enables entry into | Ranked Tournament battle | [O] TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| FFA placement | Separately determines | Match-win status and A-Coin eligibility | [O]; thresholds differ. FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| Eligible battle performance | Produces | XP, points, RP/TRP and event credit | [O]; mode/caps qualify each route. POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) |
| Custom/PvE mode context | Excludes specified routes | Ordinary progression/objective channels | [O]; exclusions are mode-specific. CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) |
| Friends/clanmates | Form | Premade team | [O]; mode restrictions remain. TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| Clan members' collection/activity | Aggregate into | Clan power/damage boards | [O] CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) |
| Timed objectives | Award | Event Points / resources / tokens | [O] EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) |
| Pass objectives | Award | Pass Points → rewards | [O] PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) |
| Club objectives/store/desktop activity | Award | Pilot Points → website-claimed rewards | [O] CLUB [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) |
| Registered community team | Is paired and adjudicated under | External organizer rules | [C]; independent of public queue logic. MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) |
| Feedback and analysis | Inform announced changes | Balance, rewards, experiments | [O-intent]; exact decision weights unknown. REBAL [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) |

## 16.3 Five end-to-end paths

### Progression path

**[O/S model]** Eligible play/objectives → account XP and resources → feature milestones and upgrades → broader legal hangar options → further play. Gear Hub Tier Stars supply a separate access path; they must not be merged into XP progression. PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies)

### Competitive path

**[O/C/S model]** Learn a ruleset → construct an eligible hangar → enter ordinary or Tournament competition → receive the relevant RP/TRP outcome → reach harder contexts → practice and adapt. For organized play, branch through registration, Custom lobbies and external series adjudication instead of assuming the in-game Tournament performs those functions. DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · MAQC [4](https://maqc.mecharenadev.com/rules)

### Social path

**[O/C/S model]** Encounter or invite a player → friend/clan relationship → repeated premade play → shared communication and practice → registered team/community reputation. Friendship does not itself confer inventory transfers or unrestricted mode eligibility. FRIEND [1](https://mecharena-support.plarium.com/hc/en-us/articles/12726680651036-How-do-I-add-friends) · TEAM [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · TRANSFER [129](https://mecharena-support.plarium.com/hc/en-us/articles/16575925235868-How-to-transfer-resources) · MAQC [4](https://maqc.mecharenadev.com/rules)

### Economy path

**[O/S model]** Earn/buy resources or tokens → acquire/upgrade content → change capability and access → compete for new eligible rewards → reinvest. Caps, separate materials, event dates and irreversible sinks constrain the loop; no player cash-out market is established. CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · POINT [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) · TRANSFER [129](https://mecharena-support.plarium.com/hc/en-us/articles/16575925235868-How-to-transfer-resources)

### Live-operations path

**[O/S model]** Announce feature/season → expose eligible players/cohorts → collect feedback and performance evidence → adjust configuration/balance/rewards → publish changes → update the knowledge base. This is a functional reconstruction, not the internal organizational approval chain. TRIALTEST [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/) · TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · REBAL6 [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) · ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/)

## 16.4 Recommended knowledge entities

For wiki or AI-agent use, represent at least these conceptual entities:

| Entity | Recommended fields | Important separation |
|---|---|---|
| Account state | Account identifier, platform links, XP, division stage, relevant feature flags. | Public player ID is not an authentication credential. |
| Owned content | Content class, ownership, grade, rank, level, compatible attachments. | Content definition differs from an account's owned/upgrade state. |
| Preset | Owned-content references, assignments, checked status, power display and date. | Preset configuration is not duplicate ownership. |
| Ruleset version | Mode, victory rules, timers, roster/life rules, normalization, exclusions, evidence. | A renamed/retired queue is not automatically the same ruleset. |
| Match record | Timestamp, build, ruleset, map, participants, party/bot uncertainty, result and scores. | Distinguish player, mech, round, match and series. |
| Competition instance | Operator, dates, active modes/maps, rank/attempt rules or external bracket policy. | Plarium Tournament and MAQC are separate namespaces. |
| Reward transaction | Source, eligibility, earned quantity, claim state, delivery, applicable caps/expiry. | Winning and being paid are different events. |
| Event objective | Predicate, event identity, repeatability, progress scope, valid modes, deadline. | Generic objectives do not automatically count PvE or Custom play. |
| Social group | Clan/friend/premade/external team, members, roles, applicable rules. | A registered event team need not equal an entire clan. |
| Evidence assertion | Claim, classification, source URL/key, time scope, retrieval date, conflict and verification needs. | A publisher promise must retain an “announced” qualifier. |

**All schema choices are [S-recommendations], not extracted game data structures.** Source grounds are the documented systems they represent. PRESET [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · INBOX [131](https://mecharena-support.plarium.com/hc/en-us/articles/16444499048476-Inbox-and-News) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · MAQC [4](https://maqc.mecharenadev.com/rules)

## 16.5 Machine-readable model rules

The companion knowledge file follows these principles:

- A system has a stable identifier and links to evidence sources.
- A relationship has a type such as `unlocks`, `requires`, `awards`, `consumes`, `caps`, `normalizes`, `excludes`, or `organized_by`.
- Evidence status and temporal status are separate fields.
- Unknown numeric values are `null`, not guessed zeroes.
- Conflicting facts retain alternatives and a resolution note; they are not flattened into one apparently authoritative value.
- Model-level architecture edges remain identified as a conceptual representation even when the underlying feature relationship is official.
- Current, historical and experimental modes are separate records.
- The model includes no item catalog, private player data, credentials or hidden algorithm constants.

**[S-design rules]** This makes the material useful for retrieval and reasoning while preserving the distinction between public product facts and an analyst's organizational model.


# 17. Fact checking, conflict ledger, unknowns and sources

## 17.1 What was and was not verified

This dossier is a **public-source research reconstruction**, not a certification of the current executable. It verifies what named sources state, resolves clear temporal replacements, and preserves uncertainty where the available evidence is incomplete or internally inconsistent.

| Research operation | Performed? | Scope |
|---|---|---|
| English support corpus collection/indexing | Yes | 127 articles indexed; systems-relevant articles reviewed. |
| Current support versus dated forum comparison | Yes | Modes, gates, Tournament, Showdown, Mods, pass, Trial and loyalty changes. |
| Official storefront/version-history review | Yes | Mobile/desktop distribution evidence, release family and regional examples. |
| Technical developer-source review | Yes | Plarium's 2024 map/navigation/synchronization/tooling article. |
| Live community-organizer rulebook review | Yes | MAQC Season 7 and current public weekly addenda. |
| Selective community corroboration | Yes | Basic gameplay observations, historical transitions and contested explanations. |
| Live-account gameplay or controlled client testing | No | Test recommendations below have not been executed. |
| Source-code/binary reverse engineering | No | No recovered client code, server code or private implementation constants. |
| Private backend access or telemetry audit | No | No verified hosting topology, MMR formula or game-wide performance dataset. |
| Exhaustive item/stat catalog | Intentionally excluded | Outside the requested systems-oriented scope. |

**Classification is not a certainty score.** An official article can be stale, a community organizer can be the best primary source for its own rules, and an analyst inference can be useful without becoming a game fact. Date, source authority, directness and conflict status must all be retained.

## 17.2 Major-claim audit summary

| Claim | Classification and disposition | Principal sources |
|---|---|---|
| Plarium game, global mobile launch 12 August 2021 | [O] Explicit launch announcement. | REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) |
| Native PC/Mac release in August 2022 | [O-historical] Explicit desktop announcement; do not confuse emulation with native release. | PC [2](https://forum.plarium.com/en/mech-arena/854_news/31666_mech-arena-is-live-on-plarium-play/) |
| Current observed release family is 3.470 | [O] Forum release notes plus storefront history. | V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) |
| Hangar capacity five; up to two weapons and one pilot per mech | [O] Explicit equipment guide. | MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) |
| Energy compatibility limits legal weapon combinations | [O] Explicit rule; not a formula for matching or damage. | MECH [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) · WEAPON [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons) |
| Rank, level, rarity, XP, RP, TRP and Tier Stars are distinct | [O; synthesis] Supported by separate system definitions. | GRADE [110](https://mecharena-support.plarium.com/hc/en-us/articles/12554603916444-Mech-or-Weapon-Grade) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) · RP [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) |
| CPC has three victory routes | [O] 100 Influence, higher Influence at time, or enemy elimination. | CPC [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) |
| Deathmatch uses round wins and a defined overtime | [O] Two-minute rounds, 30-second tied-round overtime; draw edges remain underdocumented. | DM [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) |
| FFA is Tournament-only with ten participants and five active mechs | [O] Dedicated current guide. | FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| FFA top-three winners differ from top-five A-Coin eligibility | [O] Explicit cross-source distinction. | FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| Showdown maxes battle ranks/levels and has restricted leagues | [O] Explicit feature rules; does not grant all ownership. | HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) |
| Onslaught is solo, not co-op or offline | [O] Explicit dedicated guide and online requirement. | PVE [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) · OFFLINE [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline) |
| Custom Matches are not progression farms | [O] Explicit XP/reward/objective/achievement exclusion. | CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) |
| Tournament has eight daily starts and fifteen rank steps | [O] Current dedicated guide. | TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) |
| Tournament can produce same-TRP, very different-SP opponents | [O] Explicit official explanation. | TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| Full matchmaking equation or forced 50% schedule is known | [W/S] Not established; recurring speculation is not implementation evidence. | TRNCOMM [1](https://www.reddit.com/r/mecharena/comments/1sq8nse/how_tournament_matchmaking_works_and_why_youre/) · BOTDEBATE [3](https://forum.plarium.com/mech-arena/702_game-discussion/1640073_player-discussion-this-is-an-issue/) · LOADOUT [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) |
| Clans have 30 members and separate power/damage Top 100 boards | [O] Explicit current guide. | CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) |
| Native clan wars, bank or tech tree exist | [S-unverified] No sufficient support established; do not assume. | CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) · TRANSFER [129](https://mecharena-support.plarium.com/hc/en-us/articles/16575925235868-How-to-transfer-resources) |
| Gear Hub is a sequential acquisition/rank-star access graph | [O] Mechanism clear; current total tier count conflicted. | HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HUBWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Gear_Hub) |
| Mods now unlock at mech Rank 3 and have rank-linked upgrade caps | [O] Current guide and deployed-change announcement. | MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/) |
| Implant removal preserves level; scrapping is irreversible | [O] Current dedicated implant guide. | IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) |
| Native voice and broadcast-grade observers are universally available | [S-unverified] Historical staff responses do not establish a current release. | VOICE [1](https://forum.plarium.com/mech-arena/702_game-discussion/1712472_voice-chat-system/) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) · KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430) |
| Unity and specific map/navigation/build tools are documented | [O-historical implementation] First-person Plarium engineering article. | ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) |
| Exact hosting, backend language, tick rate and full authority are known | [S-unverified] Not disclosed by reviewed technical evidence. | ENGINE [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) |
| MAQC Season 7 uses Bo3, Equalize and a 5m A-Coin advertised pool | [C] Live organizer rules and addenda; official promotion is separate evidence. | MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) · ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) |
| Paid progression affects capability | [O] Acquisition/upgrade mechanisms confirmed; actual win impact is contextual. | CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) |
| Psychological or retention effects are proven | [S] Design hypotheses only; no causal player-study dataset obtained. | EVENT [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) · PASS [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) · CLAN [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) |

The companion **evidence-ledger.csv** provides a structured claim-by-claim index with classifications, temporal scope and source URLs. Inline evidence labels and citations remain the primary support for the full narrative, including table rows and analysis blocks.

## 17.3 Version and contradiction ledger

| ID | Conflict or common error | Resolution used in this dossier |
|---|---|---|
| V01 | Storefront/overview lists ordinary 2v2 as active. | Use explicit removal FAQ; retain 2v2 as historical, not a guaranteed public queue. HSFAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) · OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) |
| V02 | Old Tournament tickets, heats and 20-player brackets presented as current. | Superseded by April 2026 eight-attempt/TRP format. Historical exploitation explanations remain historically relevant. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| V03 | “Weekly Tournament” marketing versus longer current competitions. | Official embedded FAQ says duration varies, typically three weeks. Current in-game dates are decisive. TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US) |
| V04 | Tournament/FFA unlock at Division 9 in older overview. | Current dedicated guides say Division 4 and five-mech eligibility. OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · TRN [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) · FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) |
| V05 | Custom at Division 10 versus Division 5. | Overview distinguishes general Custom access from hosting at 5; dedicated guide says feature unlocks at 5. Use 5 as the documented operational gate and verify whether younger accounts can join invitations. Do not falsely erase the possible join/host distinction. OVERVIEW [1](https://mecharena.game/mech-arena-gameplay-overview/) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) |
| V06 | FFA top three versus top five. | Top three defines match winners; May policy grants A-Coins to top five. These are compatible, not two competing win rules. FFA [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) · TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) |
| V07 | May Tournament payout reduction treated as the final current table. | June announcement increases payouts. Neither statement supplies a perpetual per-player income guarantee. TRNMAY [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) · TRNJUNE [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/) |
| V08 | Showdown five paid/free attempts versus ten free and unlimited further play. | April 2026 redesign: ten reward-bearing matches; further RP/XP matches. Older screenshots are illustrative history. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) |
| V09 | Showdown league numbers and multiplier examples disagree. | Publish the explicit restriction ladder with a warning; do not invent a current complete star/multiplier table. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) · HS20 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) |
| V10 | Showdown permits four mechs but can last five rounds with new picks. | Public rule interaction not adequately explained; fifth-round handling remains a priority live test. HS [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) |
| V11 | Mods require 30,000 XP and Rank 6 for some players. | Historical cohort policy superseded by universal Rank-3 access and host-rank upgrade caps. MODOLD [3](https://forum.plarium.com/en/mech-arena/854_news/43351_mods-feature-faq/) · MOD [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) · MODLIVE [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/) |
| V12 | Generic currency guide implies implant parts from removal. | Dedicated current implant guide distinguishes retained-level removal from irreversible scrapping. Do not apply old removal penalties as current mechanics. CURRENCY [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) · IMPLANT [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) |
| V13 | Gear Hub has eight, nine or ten tiers. | Mechanism confirmed; support says eight while current community page says ten. Total count remains unresolved pending client verification. HUB [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) · HUBWIKI [1](https://mech-arena-robot-showdown.fandom.com/wiki/Gear_Hub) |
| V14 | First pilot in tutorial versus Pilot Access at 1,000 XP. | Preserve both statements with scope warning; onboarding/cohort sequence not directly tested. BEGIN [2](https://mecharena.game/mech-arena-beginners-guide/) · PROGRESS [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) |
| V15 | “Trial Mode removed” interpreted as Onslaught Trial removed. | Content Trial withdrawal and residual cohort are separate from the still-promoted PvE trial offering. TRIALEND [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) · V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · INAPPLE [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228) |
| V16 | Old Season Top 500 described as unrewarded. | New dedicated Division guide explicitly describes end-of-season rewards by division/placement; no fixed table invented. DIV [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) |
| V17 | iOS 13/store metadata or Windows 7 page treated as current requirements. | Use current iOS 15 / Windows 10-era support; iOS notice explains last-compatible downloads. SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) · IOSNEW [138](https://forum.plarium.com/mech-arena/854_news/43692_----important-info-for-ios-players/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) · DESK [7](https://mecharena.game/mech-arena-pc-mac/) |
| V18 | 4G/LTE marketing versus support's Wi-Fi recommendation. | Separate transport support from reliability guidance. Neither implies offline capability. PLAY [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US) · OFFLINE [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline) |
| V19 | “Spectator mode” in a bug article implies full observer tools. | Distinguish an in-battle state from joining others' matches, broadcast cameras and replay export. KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430) · LOG [123](https://mecharena-support.plarium.com/hc/en-us/articles/12746581379100-What-is-Battle-History) · SPECTATE [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) |
| V20 | Same MAQC URL indexed as Season 6 but live as Season 7. | Use live rulebook/weekly addenda; retain Season 6 format as historical only. MAQC6 [1](https://www.reddit.com/r/mecharena/comments/1tml0fs/mech_arena_quarterly_clash_season_6_registrations/) · MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) |
| V21 | MAQC anniversary pool announced as 2m versus current 5m. | Attribute 2m to July publisher announcement and 5m to current organizer rules; do not silently rewrite history. ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · MAQCLIVE [144](https://maqc.mecharenadev.com/) |
| V22 | MAQC registration dates differ between announcement/homepage/rules. | Registration is closed at snapshot. Exact historical deadline requires dated organizer adjudication; do not manufacture reconciliation. ANN5 [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) · MAQC [4](https://maqc.mecharenadev.com/rules) · MAQCLIVE [144](https://maqc.mecharenadev.com/) |
| V23 | Old MAQC SP tolerances or DM evidence policy used for Week 4. | Current addenda add hidden tolerance variance and require assigned battle-post communication/evidence. MAQCLIVE [144](https://maqc.mecharenadev.com/) |
| V24 | Known-issues article title 3.430 implies the newest client is 3.430. | Current release family is 3.470. A living help article title is not a release index. KNOWN [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430) · V347 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) · APPLE [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) |
| V25 | Support `updated_at` implies a feature launched or changed that day. | Metadata records the page/API state, not a guaranteed release event. Prefer substantive announcement/body dates. |
| V26 | “Global” launch or one age label implies universal country/device/age eligibility. | Regional storefronts, legal age flows and current device requirements remain separate gates. REL [1](https://company.plarium.com/en/articles/mech-arena-global-release/) · INPLAY [101](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en&gl=IN) · INAPPLE [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228) · AGEAPPLE [139](https://mecharena-support.plarium.com/hc/en-us/articles/28973369510172-Age-Verification-FAQ) · SPEC [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) |

## 17.4 Unresolved questions that affect implementation or operations

| Priority | Question | Why it matters / next evidence needed |
|---|---|---|
| High | Full current Showdown league thresholds, ordering and reward multipliers? | Build eligibility and reward forecasting; inspect every live league card. |
| High | Showdown timeout/draw rules and four-mech/fifth-round behavior? | A complete rules engine and reliable organized format require these edges. |
| High | Current TRP gain/loss, thresholds, reseeding and reward tables? | Forecasting and competitive analysis; capture the current Guidelines and result samples. |
| High | Which Custom modes and observer options are presently available? | Organizer rehearsal; do not infer from stale cross-links or player videos. |
| High | Matchmaking weights, widening and novice protection? | Only authoritative disclosure or carefully controlled evidence can support a fuller model. |
| Medium | Current complete Gear Hub tier count and threshold table? | Economy simulation; compare live UI with support/community discrepancy. |
| Medium | Exact match-draw edge cases and normal respawn-protection/reset rules? | Rule emulation and dispute procedures need more than a general mode summary. |
| Medium | Pilot tutorial/access sequence across new-account cohorts? | New-player walkthrough accuracy; document cohort and app version. |
| Medium | Per-mode objective, Pilot XP, clan-damage and result-history eligibility? | Do not infer every secondary-stat route from one broad “battle” statement. |
| Medium | Current Showdown friend-premade rollout status? | Social/tournament planning; no universal availability proven here. |
| Medium | Current native voice, replay and observer roadmap? | Broadcast and coordination planning; promises are not shipped capabilities. |
| Research-dependent | Hosting stack, transport, authority, tick rate and anti-cheat implementation? | Requires technical disclosure; not reconstructible from a product page. |
| Research-dependent | Active users, per-mode humans/bots, revenue, currency issuance and retention? | Needs reliable telemetry or audited market data, not download totals. |

All unresolved entries are **[S-unknown]**. “Unknown” does not mean a feature is absent, broken or secret for malicious reasons; it means the reviewed evidence does not settle the question.

## 17.5 Validation plan for a future live-client study

The following tests are **proposed, not performed [S]**. Use permitted private/test contexts where available. Do not collude in ranked public matches, manipulate opponents, bypass anti-cheat or obtain unauthorized test accounts. CONDUCT [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) · CUSTOM [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) · CREATOR [1](https://forum.plarium.com/mech-arena/702_game-discussion/1444827_developer-build/)

| Test | Record | Verification target |
|---|---|---|
| Eligibility walkthrough | Fresh-account cohort, XP/RP, mode cards and invitation behavior. | Distinguish feature gates, join/host access and tutorial variants. |
| CPC terminal states | Influence/time/elimination condition plus result. | Rule completion timing; separate known delay bugs from intended rules. |
| Deathmatch draws | Round outcomes, overtime and match result in a permitted lobby. | Complete draw handling without inventing a fourth round. |
| FFA result audit | Natural-match placement, final-blow score, win status and currency payout. | Top-three/top-five distinction and current TRP/reward amounts. |
| Showdown full sequence | All league cards, allowed layers, four/five-mech state, timeout result and reward-track changes. | Resolve underdocumented rules and stale illustrations. |
| Preset comparison | Checked presets, selected lineup, actual deployed equipment and displayed lobby SP. | Separate known display bug from real matching inputs. |
| Reward-route audit | Before/after counters, mode, booster/cap state, objectives and Inbox. | Build a mode-qualified reward ledger. |
| Organizer rehearsal | Roster/ID verification, bot setting, maps, screenshot submission and any observer access. | Confirm practical competition operations before publishing promises. |

## 17.6 Maintenance protocol

**[S-recommendation]** Update this dossier at each major system release and before using it as an organizer rulebook. Review latest support plus dated announcements; capture the active client/event rules; update changed assertions with valid-from/valid-to fields; preserve superseded rules rather than overwriting them; rerun dependency and citation checks; and regenerate the human-readable and machine-readable artifacts together.

Use a risk-based review order: Tournament/Showdown rules and reward changes first, competition addenda next, then progression/economy/eligibility changes, and finally cosmetic or non-system additions. Public matchmaking and backend assumptions should never gain confidence merely because they have remained copied across several documents.

## 17.7 Source register

**All sources were accessed for this research on 7 September 2026.** Dates shown below are substantive publication/update dates where established, not the raw help-center API's frequently refreshed metadata. “Undated/current page” means no reliable single publication date was assigned. Source classifications identify the source's role; a mixed forum page's ordinary user comments are not automatically official.

### Primary feature documentation

| Key | Document / direct link | Source authority | Date and use notes |
|---|---|---|---|
| **RP** | Ranking Points [1](https://mecharena-support.plarium.com/hc/en-us/articles/12541826418716-Ranking-Points) | Official | 2025-07-09. Loss wording is ambiguous beyond the stated zero/-60 cases; do not invent interpolation. |
| **DIV** | Divisions [103](https://mecharena-support.plarium.com/hc/en-us/articles/28037009974812-Divisions) | Official | Undated/current page. Current dedicated Division guide includes end-of-season rewards. |
| **TRN** | Tournament [4](https://mecharena-support.plarium.com/hc/en-us/articles/26460759415708-Tournament) | Official | 2026-04-07. Text plus official four-frame GIF. GIF Overview says duration varies, typically three weeks, Tuesday to Monday, often with a one-day break. Applies to reworked system. |
| **HS** | Hangar Showdown [7](https://mecharena-support.plarium.com/hc/en-us/articles/21315375576604-Hangar-Showdown) | Official | 2026-04-03. Contains an inconsistent League-4 multiplier example and older illustrative screenshot; do not infer a reliable full league table. |
| **CPC** | Control Point Clash [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575748507548-Control-Point-Clash) | Official | 2024-05-08. Feature-specific public reference. |
| **DM** | 5 vs 5 Deathmatch [4](https://mecharena-support.plarium.com/hc/en-us/articles/12642671561116-5-vs-5-Deathmatch) | Official | 2024-05-09. Feature-specific public reference. |
| **FFA** | Free-For-All (FFA) [105](https://mecharena-support.plarium.com/hc/en-us/articles/28209735096988-Free-For-All-FFA) | Official | Undated/current page. Dedicated FFA rules created June 2026. Top-three winners differ from top-five A-Coin eligibility. |
| **PVE** | Onslaught [3](https://mecharena-support.plarium.com/hc/en-us/articles/26714436408348-Onslaught) | Official | 2026-04-11. Feature-specific public reference. |
| **CUSTOM** | What is a Custom Match? [5](https://mecharena-support.plarium.com/hc/en-us/articles/12519308886940-What-is-a-Custom-Match) | Official | 2025-01-08. Division 5 and no progression rewards. Legacy 2v2 cross-link is not proof of a current public queue. |
| **PRESET** | Squad Presets [106](https://mecharena-support.plarium.com/hc/en-us/articles/12555277712028-Squad-Presets) | Official | Undated/current page. Feature-specific public reference. |
| **LOADOUT** | Hangar Loadout and How It Affects Your Battle Experience [2](https://mecharena-support.plarium.com/hc/en-us/articles/28927106715036-Hangar-Loadout-and-How-It-Affects-Your-Battle-Experience) | Official | 2026-07-16. Feature-specific public reference. |
| **SP** | Squad Power [2](https://mecharena-support.plarium.com/hc/en-us/articles/12555172477468-Squad-Power) | Official | 2024-05-07. Feature-specific public reference. |
| **HUB** | What is the Market? [8](https://mecharena-support.plarium.com/hc/en-us/articles/12575140491420-What-is-the-Market) | Official | 2025-02-06. Core Tier Star mechanics valid as documented; eight-tier count conflicts with current community ten-tier listing. |
| **HUBFAQ** | Gear Hub FAQ [107](https://mecharena-support.plarium.com/hc/en-us/articles/12640339449372-Gear-Hub-FAQ) | Official | Undated/current page. Feature-specific public reference. |
| **MECH** | General info about Mechs [108](https://mecharena-support.plarium.com/hc/en-us/articles/12538459799196-General-info-about-Mechs) | Official | Undated/current page. Feature-specific public reference. |
| **WEAPON** | General info about Weapons [109](https://mecharena-support.plarium.com/hc/en-us/articles/13895067286812-General-info-about-Weapons) | Official | Undated/current page. Feature-specific public reference. |
| **GRADE** | Mech or Weapon Grade [110](https://mecharena-support.plarium.com/hc/en-us/articles/12554603916444-Mech-or-Weapon-Grade) | Official | Undated/current page. Feature-specific public reference. |
| **MOD** | Mods [4](https://mecharena-support.plarium.com/hc/en-us/articles/26408501325468-Mods) | Official | 2026-04-02. Feature-specific public reference. |
| **PILOT** | Pilots [112](https://mecharena-support.plarium.com/hc/en-us/articles/12555420276508-Pilots) | Official | Undated/current page. Feature-specific public reference. |
| **IMPLANT** | Implants [113](https://mecharena-support.plarium.com/hc/en-us/articles/15606941350940-Implants) | Official | Undated/current page. Current removal retains implant level; older removal-cost assumptions must not be reused. |
| **POINT** | Points [4](https://mecharena-support.plarium.com/hc/en-us/articles/12575863084316-Points) | Official | 2024-05-09. Uses Battle Points and Combat Points inconsistently in its opening; report namespaces Showdown points separately. |
| **CAP** | I won a battle but got no rewards. Why? [8](https://mecharena-support.plarium.com/hc/en-us/articles/12642357164700-I-won-a-battle-but-got-no-rewards-Why) | Official | 2025-05-14. Feature-specific public reference. |
| **OBJECTIVE** | Regular Objectives [114](https://mecharena-support.plarium.com/hc/en-us/articles/12575337424412-Regular-Objectives) | Official | Undated/current page. Feature-specific public reference. |
| **PROGRESS** | Progress Path [115](https://mecharena-support.plarium.com/hc/en-us/articles/26714386938908-Progress-Path) | Official | Undated/current page. Feature-specific public reference. |
| **CURRENCY** | Game Currencies [116](https://mecharena-support.plarium.com/hc/en-us/articles/12572953859100-Game-Currencies) | Official | Undated/current page. Feature-specific public reference. |
| **CRATE** | Crates [3](https://mecharena-support.plarium.com/hc/en-us/articles/12572383405084-Crates) | Official | 2026-04-01. Feature-specific public reference. |
| **VAULT** | Fortune Vaults [117](https://mecharena-support.plarium.com/hc/en-us/articles/12572771158556-Fortune-Vaults) | Official | Undated/current page. Feature-specific public reference. |
| **LOGIN** | Daily Login Program [118](https://mecharena-support.plarium.com/hc/en-us/articles/12559453400732-Daily-Login-Program) | Official | Undated/current page. Baseline seven-day welcome and 28-day recurring program; version history announces additional login programs. |
| **ACHIEVE** | Mech Achievements [119](https://mecharena-support.plarium.com/hc/en-us/articles/12575503767708-Mech-Achievements) | Official | Undated/current page. Feature-specific public reference. |
| **EVENT** | Game Events [9](https://mecharena-support.plarium.com/hc/en-us/articles/12537703494172-Game-Events) | Official | 2026-04-01. Feature-specific public reference. |
| **PASS** | Battle Pass [2](https://mecharena-support.plarium.com/hc/en-us/articles/27565089551644-Battle-Pass) | Official | 2026-07-07. Feature-specific public reference. |
| **CLUB** | What is Arena Pilot Club? [1](https://mecharena-support.plarium.com/hc/en-us/articles/29884742867484-What-is-Arena-Pilot-Club) | Official | 2026-09-01. Feature-specific public reference. |
| **CLAN** | Clans [121](https://mecharena-support.plarium.com/hc/en-us/articles/27564468271516-Clans) | Official | Undated/current page. Feature-specific public reference. |
| **TEAM** | How to play with friends and clanmates? [7](https://mecharena-support.plarium.com/hc/en-us/articles/12576042565148-How-to-play-with-friends-and-clanmates) | Official | 2024-02-14. Feature-specific public reference. |
| **FRIEND** | How do I add friends? [1](https://mecharena-support.plarium.com/hc/en-us/articles/12726680651036-How-do-I-add-friends) | Official | 2025-04-18. Feature-specific public reference. |
| **REFERRAL** | What is the Referral Program? [122](https://mecharena-support.plarium.com/hc/en-us/articles/13609574565788-What-is-the-Referral-Program) | Official | Undated/current page. Feature-specific public reference. |
| **LOG** | What is Battle History?  [123](https://mecharena-support.plarium.com/hc/en-us/articles/12746581379100-What-is-Battle-History) | Official | Undated/current page. Feature-specific public reference. |
| **AWARD** | Battle Awards [6](https://mecharena-support.plarium.com/hc/en-us/articles/12642067896860-Battle-Awards) | Official | 2025-01-08. Feature-specific public reference. |
| **MEDAL** | Medals [2](https://mecharena-support.plarium.com/hc/en-us/articles/12642305648796-Medals) | Official | 2025-09-26. Feature-specific public reference. |
| **CHEAT** | How to report cheaters? [124](https://mecharena-support.plarium.com/hc/en-us/articles/12865857341724-How-to-report-cheaters) | Official | Undated/current page. Feature-specific public reference. |
| **BAN** | Why was I banned? [125](https://mecharena-support.plarium.com/hc/en-us/articles/12865625608220-Why-was-I-banned) | Official | Undated/current page. Feature-specific public reference. |
| **CONDUCT** | What is considered a violation of the Rules of Conduct? [126](https://mecharena-support.plarium.com/hc/en-us/articles/12848619583004-What-is-considered-a-violation-of-the-Rules-of-Conduct) | Official | Undated/current page. Feature-specific public reference. |
| **SYNC** | Cheater or Game Mechanic? [127](https://mecharena-support.plarium.com/hc/en-us/articles/27620757593756-Cheater-or-Game-Mechanic) | Official | Undated/current page. Supports latency explanation, not proof that every suspicious behavior is innocent; heuristic red flags are not conclusive cheat evidence. |
| **KNOWN** | Known issues in the game version 3.430 [6](https://mecharena-support.plarium.com/hc/en-us/articles/13936213393948-Known-issues-in-the-game-version-3-430) | Official | 2026-04-25. Living article title remains 3.430; not the current client release identifier. |
| **GIFT** | What are Plarium Store and Plarium Store gifts? [128](https://mecharena-support.plarium.com/hc/en-us/articles/16673365892252-What-are-Plarium-Store-and-Plarium-Store-gifts) | Official | Undated/current page. Feature-specific public reference. |
| **TRANSFER** | How to transfer resources? [129](https://mecharena-support.plarium.com/hc/en-us/articles/16575925235868-How-to-transfer-resources) | Official | Undated/current page. Feature-specific public reference. |
| **PROMO** | What is a Promo Code? [130](https://mecharena-support.plarium.com/hc/en-us/articles/15036191425308-What-is-a-Promo-Code) | Official | Undated/current page. Feature-specific public reference. |
| **INBOX** | Inbox and News [131](https://mecharena-support.plarium.com/hc/en-us/articles/16444499048476-Inbox-and-News) | Official | Undated/current page. Feature-specific public reference. |
| **SETTING** | Game Settings [132](https://mecharena-support.plarium.com/hc/en-us/articles/12746754445724-Game-Settings) | Official | Undated/current page. Feature-specific public reference. |
| **CONTROL** | Controls and Battle Settings [1](https://mecharena-support.plarium.com/hc/en-us/articles/12575581245340-Controls-and-Battle-Settings) | Official | 2025-07-10. Feature-specific public reference. |
| **ACCOUNT** | How do I save the game? How do I play on different devices? [133](https://mecharena-support.plarium.com/hc/en-us/articles/12725954495644-How-do-I-save-the-game-How-do-I-play-on-different-devices) | Official | Undated/current page. Feature-specific public reference. |
| **ID** | What is Plarium ID? [134](https://mecharena-support.plarium.com/hc/en-us/articles/26835074933532-What-is-Plarium-ID) | Official | Undated/current page. Feature-specific public reference. |
| **PCSYNC** | How to continue my progress on Plarium Play? [135](https://mecharena-support.plarium.com/hc/en-us/articles/12759575300636-How-to-continue-my-progress-on-Plarium-Play) | Official | Undated/current page. Feature-specific public reference. |
| **OFFLINE** | Can I play the game offline? [136](https://mecharena-support.plarium.com/hc/en-us/articles/12726090063772-Can-I-play-the-game-offline) | Official | Undated/current page. No offline mode; recommends stable Wi-Fi. Store says cellular supported; support wording is reliability advice, not a cellular prohibition. |
| **SPEC** | Mech Arena: System Requirements & Performance Guide [137](https://mecharena-support.plarium.com/hc/en-us/articles/28953959959708-Mech-Arena-System-Requirements-Performance-Guide) | Official | Undated/current page. Feature-specific public reference. |
| **AGEAPPLE** | Age Verification FAQ [139](https://mecharena-support.plarium.com/hc/en-us/articles/28973369510172-Age-Verification-FAQ) | Official | Undated/current page. Feature-specific public reference. |
| **AGEPLAY** | Age Verification FAQ [140](https://mecharena-support.plarium.com/hc/en-us/articles/28974098136220-Age-Verification-FAQ) | Official | Undated/current page. Feature-specific public reference. |
| **SUPPORT** | How to contact Support? [3](https://mecharena-support.plarium.com/hc/en-us/articles/13793049362332-How-to-contact-Support) | Official | 2025-07-25. Feature-specific public reference. |
| **BUG** | How to create a good bug report? [141](https://mecharena-support.plarium.com/hc/en-us/articles/13793527485852-How-to-create-a-good-bug-report) | Official | Undated/current page. Feature-specific public reference. |
| **COMMUNITY** | Mech Arena Official Communities [142](https://mecharena-support.plarium.com/hc/en-us/articles/13793210473756-Mech-Arena-Official-Communities) | Official | Undated/current page. Feature-specific public reference. |
| **BLUEPRINT** | Why do I need Blueprints? [146](https://mecharena-support.plarium.com/hc/en-us/articles/12554910155676-Why-do-I-need-Blueprints) | Official | Undated/current page. Feature-specific public reference. |
| **MODIFIER** | Modifiers [147](https://mecharena-support.plarium.com/hc/en-us/articles/28037635539100-Modifiers) | Official | Undated/current page. Feature-specific public reference. |
| **SPAM** | Anti-spam system [148](https://mecharena-support.plarium.com/hc/en-us/articles/12848258278556-Anti-spam-system) | Official | Undated/current page. Feature-specific public reference. |
| **SECURITY** | Security Policy. How to Keep your Account Safe [149](https://mecharena-support.plarium.com/hc/en-us/articles/12831378454684-Security-Policy-How-to-Keep-your-Account-Safe) | Official | Undated/current page. Feature-specific public reference. |
| **UPGRADE** | How can I increase Squad Power? [150](https://mecharena-support.plarium.com/hc/en-us/articles/12739688618780-How-can-I-increase-Squad-Power) | Official | Undated/current page. Feature-specific public reference. |

### Publisher, storefront and official-community sources

| Key | Document / direct link | Source authority | Date and use notes |
|---|---|---|---|
| **WEB** | Mech Arena official website [7](https://mecharena.game/) | Official | Undated/current page. Broad product identification; mode list is not a reliable current queue inventory. |
| **REL** | Global mobile launch announcement [1](https://company.plarium.com/en/articles/mech-arena-global-release/) | Official | 2021-08-12. See inline scope qualifications. |
| **PC** | Mech Arena is live on Plarium Play [2](https://forum.plarium.com/en/mech-arena/854_news/31666_mech-arena-is-live-on-plarium-play/) | Official | 2022-08-03. Historical desktop release and Denuvo disclosure; not proof of unchanged 2026 integration. |
| **DESK** | Mech Arena on PC and Mac [7](https://mecharena.game/mech-arena-pc-mac/) | Official | Undated/current page. Cross-progression and launcher updates useful; old Windows requirements superseded. |
| **MTG** | MTG: Plarium company profile [1](https://www.mtg.com/midcore-district/plarium/) | Official | 2025-02-12. Acquisition closing date; this is not a change of game publisher. |
| **ANN4** | Fourth anniversary announcement [7](https://company.plarium.com/en/articles/mech-arena-celebrates-its-4th-anniversary/) | Official | 2025-08-08. 80 million lifetime downloads is a dated publisher claim, not active users. |
| **ANN5** | Fifth anniversary announcement [2](https://company.plarium.com/en/articles/mech-arena-celebrates-5th-anniversary%20/) | Official | 2026-07-31. Announces 2m A-Coins for MAQC; live organizer site later lists 5m. |
| **V347** | Release Notes 3.470 [3](https://forum.plarium.com/mech-arena/854_news/43787_release-notes-3-470/) | Official | 2026-08-31. See inline scope qualifications. |
| **ENGINE** | A Deep Dive into Level Design: Creating Interactive Moving Objects [2](https://company.plarium.com/en/articles/interactive-moving-objects-for-pvp-shooter-mech-arena-maps/) | Official | 2024-06-25. First-person technical account by Plarium level designer Daniil Honcharenko. Implementation details are dated to this account. |
| **PRODUCT** | Mech Arena product and desktop requirements [5](https://plarium.com/en/game/mech-arena/) | Official | Undated/current page. Current system requirements; promotional mode copy still mentions legacy 2v2. |
| **APPLE** | Apple App Store: version history [2](https://apps.apple.com/us/app/mech-arena-shooting-game/id1377591228) | Official | Undated/current page. 3.470 available; store compatibility metadata can describe last-compatible versions. |
| **PLAY** | Google Play: Mech Arena [9](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en_US) | Official | 2026-08-27. See inline scope qualifications. |
| **INPLAY** | Google Play, India storefront [101](https://play.google.com/store/apps/details?id=com.plarium.mechlegion&hl=en&gl=IN) | Official | Undated/current page. Retrieved directly with country parameter; locale language alone is not proof of regional distribution. |
| **INAPPLE** | Apple App Store, India storefront [102](https://apps.apple.com/in/app/mech-arena-shooting-game/id1377591228) | Official | Undated/current page. See inline scope qualifications. |
| **HSFAQ** | Hangar Showdown FAQ [1](https://forum.plarium.com/mech-arena/854_news/43372_hangar-showdown-faq/) | Official | 2025-08-07. Dates in search snippet were misleading; main post is August 7, 2025. Confirms removal of normal 2v2 queue. |
| **HS20** | Hangar Showdown 2.0 [104](https://forum.plarium.com/mech-arena/854_news/43625_hangar-showdown-2-0/) | Official | 2026-03-19. Announces April 2 release; subsequent support confirms ten free reward-bearing matches and unlimited further play. |
| **HUBOUT** | Gear Hub is out [7](https://plarium.com/forum/en/mech-arena/854_news/42409_gear-hub-is-out/) | Official | 2023-08-31. See inline scope qualifications. |
| **MODOLD** | Mods Feature FAQ [3](https://forum.plarium.com/en/mech-arena/854_news/43351_mods-feature-faq/) | Official | 2025-07-16. Historical cohort restrictions, superseded by April 2026 universal Rank-3 rule. |
| **MODREWORK** | Mods Rework Announcement [4](https://forum.plarium.com/mech-arena/854_news/43624_-mods-rework-announcement/) | Official | 2026-03. April 2 rework; refund only of invested Mod resources above new level caps, not general cash refunds. |
| **MODLIVE** | Mods rework is live [111](https://forum.plarium.com/mech-arena/854_news/43637_the-long-awaited-mods-rework-is-finally-live/) | Official | 2026-04-02. See inline scope qualifications. |
| **PASS67** | Battle Pass Updates [120](https://forum.plarium.com/mech-arena/854_news/43601_battle-pass-updates/) | Official | 2026-02-25. See inline scope qualifications. |
| **CLANOUT** | Clans Are Here [1](https://plarium.com/forum/en/mech-arena/854_news/41890_clans-are-here/) | Official | 2022-11-24. See inline scope qualifications. |
| **VOICE** | Community manager response: voice chat [1](https://forum.plarium.com/mech-arena/702_game-discussion/1712472_voice-chat-system/) | Official | 2024-10-10. Historical official response; no later native-voice launch confirmed in sources reviewed. |
| **SPECTATE** | Community manager response: spectators and bots [3](https://forum.plarium.com/pl/mech-arena/702_game-discussion/1444169_things-i-would-like-to-see-in-mech-arena/) | Official | 2023. Only the identified community manager reply is treated as official, not the user post or injected external link. |
| **STORE** | Official Mech Arena store [1](https://store.plarium.com/en/mech-arena/) | Official | Undated/current page. See inline scope qualifications. |
| **IOSNEW** | Important information for iOS players [138](https://forum.plarium.com/mech-arena/854_news/43692_----important-info-for-ios-players/) | Official | 2026-05. iOS 14 and earlier no longer support future updates; store may provide a last-compatible build. |
| **DISCORD** | Mech Arena Official Discord description [5](https://discord.com/servers/mech-arena-official-542314937624690688) | Official | Undated/current page. See inline scope qualifications. |
| **CREATOR** | Community manager response: creator test server [1](https://forum.plarium.com/mech-arena/702_game-discussion/1444827_developer-build/) | Official | 2023. Historical creator-program eligibility not asserted as unchanged current policy. |
| **TRIALTEST** | Trial Mode Test [2](https://forum.plarium.com/mech-arena/854_news/43654_trial-mode-test/) | Official | 2026-04. See inline scope qualifications. |
| **TRIALEND** | Trial Mode Update [5](https://forum.plarium.com/mech-arena/854_news/43756_trial-mode-update/2/) | Official | 2026-07-29. Content Trial withdrawn from existing participants August 3 with limited new-player experiment retained. Separate from Onslaught Trial. |
| **TRNMAY** | Tournament Progression Update: Navigating the New Curve [1](https://forum.plarium.com/mech-arena/854_news/43673_tournament-progression-update---navigating-the-new-curve/) | Official | 2026-05-05. See inline scope qualifications. |
| **TRNJUNE** | Tournament Updates [6](https://forum.plarium.com/mech-arena/854_news/43709_tournament-updates/) | Official | 2026-06-02. See inline scope qualifications. |
| **REBAL** | Rebalance Announcement [10](https://forum.plarium.com/mech-arena/854_news/43477_rebalance-announcement/) | Official | 2025-11-13. Stated goals and planned cadence, not proof of achieved balance or fulfilled content slowdown. |
| **REBAL6** | Rebalance: Sixth Wave [143](https://forum.plarium.com/mech-arena/854_news/43775_---rebalance-6th-wave/) | Official | 2026-08-21. Announces September 4 changes; includes mobile-control ergonomics rationale. |
| **CAL** | Plarium Play Event Schedule 11 [2](https://forum.plarium.com/es/mech-arena/854_news/43786_plarium-play-event-schedule--11/) | Official | 2026-09-01. Despite title, article says listed events launch across all platforms. |
| **MAQCOFF** | Official promotion of MAQC Season 6 [3](https://x.com/MechArenaMobile/status/2058872024777252880) | Official | 2026-05-25. See inline scope qualifications. |
| **BEGIN** | Mech Arena Beginner's Guide [2](https://mecharena.game/mech-arena-beginners-guide/) | Official | Undated/current page. General mechanics; tutorial-pilot statement conflicts with dedicated XP unlock guide. |
| **OVERVIEW** | Mech Arena Gameplay Overview [1](https://mecharena.game/mech-arena-gameplay-overview/) | Official | Undated/current page. Useful broad loop, but legacy tournament tickets, Division unlocks and mode list are superseded. |
| **BOT2026** | OP bots: community reports and manager replies [5](https://forum.plarium.com/mech-arena/702_game-discussion/1757208_op-bots/) | Official | 2026-03. Manager confirms bot improvement work; user allegations are not officially confirmed. |

### Community and organizer sources

| Key | Document / direct link | Source authority | Date and use notes |
|---|---|---|---|
| **HUBWIKI** | Gear Hub [1](https://mech-arena-robot-showdown.fandom.com/wiki/Gear_Hub) | Community / organizer | Undated/current page. Ten tiers currently listed; individual paragraphs mix update vintages. Do not import the whole page uncritically. |
| **MAQC** | MAQC Season 7 rulebook [4](https://maqc.mecharenadev.com/rules) | Community / organizer | Undated/current page. Live page is Season 7; indexed search description says Season 6. Capture live body, and apply weekly addenda. |
| **MAQCLIVE** | MAQC Season 7 live organizer announcements [144](https://maqc.mecharenadev.com/) | Community / organizer | Undated/current page. September 7 snapshot: Week 4 of 6, 5m A-Coins, Bo3, Equalize bots; scheduling and power-reporting addenda override older summaries. |
| **MAQC6** | MAQC Season 6 registration announcement [1](https://www.reddit.com/r/mecharena/comments/1tml0fs/mech_arena_quarterly_clash_season_6_registrations/) | Community / organizer | 2026-05-24. Historical: single-match weekly, eight brackets. Do not apply unchanged to Season 7. |
| **BEGINWIKI** | Beginner's Guide [3](https://mech-arena-robot-showdown.fandom.com/wiki/Beginner's_Guide) | Community / organizer | Undated/current page. Tutorial observations and basic controls, not current matchmaking advice or exact universal tutorial sequence. |
| **LEVELWIN** | Mech Arena beginner guide: first-hand play account [7](https://www.levelwinner.com/mech-arena-robot-showdown-beginners-guide-tips-tricks-strategies/) | Community / organizer | 2021-09-23. Historical spawn/life/round mechanics corroborated where possible, not current unlock or economy guide. |
| **MODESWIKI** | Game Modes [1](https://mech-arena-robot-showdown.fandom.com/wiki/Game_Modes) | Community / organizer | Undated/current page. Supplementary round-life and draw observations; incorrectly conflates Hangar Showdown and legacy 2v2 in heading. |
| **BOTDEBATE** | Player Discussion: This IS an issue [3](https://forum.plarium.com/mech-arena/702_game-discussion/1640073_player-discussion-this-is-an-issue/) | Community discussion | 2024-02. Evidence of competing beliefs about bot bias, not proof of fixed outcomes or a 50% win-rate target. |
| **TRNCOMM** | How tournament matchmaking works: community interpretation [1](https://www.reddit.com/r/mecharena/comments/1sq8nse/how_tournament_matchmaking_works_and_why_youre/) | Community discussion | 2026-04-20. Includes disputed MMR, fixed-50% and score claims. Used to document uncertainty, not as algorithm specification. |
| **CLANSOC** | Clan recruitment and external voice coordination example [3](https://www.reddit.com/r/mecharena/comments/10nk1wv/new_clan_forming_looking_for_members/) | Community / organizer | 2023-01-29. See inline scope qualifications. |


## 17.8 Final synthesis

**[S-synthesis grounded in the evidence throughout]** Mech Arena is best understood as a short-session tactical action game embedded in a persistent, multi-currency progression and live-operations system. Its defining architectural feature is not any one piece of equipment; it is the interaction between a configurable multi-mech roster, different mode-specific life economies, multiple ranking systems, conditional reward routes, social coordination and continual rule changes.

The most reliable way to reason about it is to keep **ownership, capability, access, rating, rewards, time and evidence** separate. That separation explains why a win need not produce every reward, why equal rating need not imply equal equipment, why a clan leaderboard is not a clan-war ranking, why Showdown normalization is not universal ownership equality, and why a community best-of-three event is not the in-game Tournament button.

This document supplies a comprehensive public-system map and the evidence boundaries needed to extend it responsibly. It intentionally leaves undisclosed implementation details undisclosed rather than filling them with plausible but unverified architecture.
